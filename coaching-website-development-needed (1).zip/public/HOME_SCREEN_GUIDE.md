# 📱 How to Add Pandit Maths Classes to Your Phone Home Screen

## For Android Users (Chrome Browser):

1. **Open your website** in Chrome browser on your phone
2. **Tap the three dots (⋮)** menu in the top-right corner
3. **Select "Add to Home Screen"** or "Install App"
4. **Tap "Add"** to confirm
5. **Your app icon will appear** on your phone's home screen!

## For iPhone Users (Safari Browser):

1. **Open your website** in Safari browser on your iPhone
2. **Tap the Share button** (square with arrow) at the bottom of the screen
3. **Scroll down and tap "Add to Home Screen"**
4. **Tap "Add"** in the top-right corner
5. **Your app icon will appear** on your phone's home screen!

## For iPad Users (Safari Browser):

1. **Open your website** in Safari on your iPad
2. **Tap the Share button** (square with arrow)
3. **Scroll down and tap "Add to Home Screen"**
4. **Tap "Add"** to confirm
5. **Your app icon will appear** on your iPad's home screen!

## Important Notes:

✅ **The website must be hosted** (deployed to Netlify, Vercel, or any web hosting)
✅ **The website must use HTTPS** (most hosting platforms provide this automatically)
✅ **Your logo file (logo.jpg)** should be in the `public` folder for the best experience
✅ **Clear browser cache** if the option doesn't appear immediately

## Troubleshooting:

**If "Add to Home Screen" doesn't appear:**

1. Make sure you're using the **official website URL** (not a shortened link)
2. Try **opening in a new incognito/private window**
3. **Restart your browser** and try again
4. **Check if the website is hosted** on HTTPS (not HTTP)
5. **Wait a few minutes** after deploying - sometimes it takes time to register

**For Android:**
- Make sure Chrome is updated to the latest version
- Try using the latest version of Chrome from Google Play Store

**For iPhone/iPad:**
- Make sure iOS is updated to the latest version
- Try Safari browser (not third-party browsers)

## What You'll Get:

 **App-like experience** - Opens like a real app, not in a browser tab
🎯 **Quick access** - Tap the icon to open your coaching website instantly
🎯 **No browser address bar** - Full-screen experience
🎯 **Homework Portal** - Easy access to student homework
🎯 **Contact buttons** - Direct call and message options

## Your App Features:

📚 **Main Website:**
- Complete coaching information
- Fee structure for all classes
- Contact details and location
- Live Google Maps integration

🏠 **Homework Portal:**
- View homework for Classes 7-10
- Subject-wise homework (Maths, Science, English)
- Due date tracking
- Teacher login (ID: AM2006, Password: @sk122aa)

## Next Steps:

1. **Deploy your website** to Netlify or Vercel (FREE hosting)
2. **Add your logo** to the public folder (name it: logo.jpg)
3. **Test on your phone** using the steps above
4. **Share with students and parents** so they can add it too!

## Need Help?

If you're still having trouble, please contact:
📞 **9244871784** or **9755874248**
📧 **panditmathsclasses@gmail.com**

---

**Pandit Maths Classes** - Where Numbers Transform into Dreams! 🌟
