import { useEffect, useState } from 'react';
import { BookOpen, LogOut, Pencil, Trash2, UserCheck, UserPlus, Users } from 'lucide-react';
import {
  getAllParentsFromFirebase,
  getAllStudentsFromFirebase,
  getHomePageDataFromFirebase,
  getTeachersFromFirebase,
  saveHomePageDataToFirebase,
  saveParentToFirebase,
  saveStudentToFirebase,
  saveTeacherToFirebase,
} from './firebase';

interface Student {
  id: string;
  name: string;
  class: string;
  username: string;
  password: string;
  purchasedMaterials: string[];
  isCoachingStudent: boolean;
}

interface Parent {
  id: string;
  parentUsername: string;
  parentPassword: string;
  studentUsername: string;
  studentName: string;
  studentClass: string;
  parentName: string;
  parentPhone: string;
  parentId: string;
}

interface TeacherInfo {
  id: string;
  name: string;
  qualification: string;
  subjectsLine: string;
  photoFileName: string;
  photoDataUrl?: string;
}

interface HomePageConfig {
  coachingName: string;
  tagline: string;
  phoneNumbers: string[];
  email: string;
  address: string;
  logoFileName?: string;
  logoDataUrl?: string;
  heroTitle?: string;
  heroSubtitle?: string;
}

interface TeacherPortalProps {
  onBack: () => void;
}

const defaultTeachers: TeacherInfo[] = [
  {
    id: 'alok',
    name: 'Alok Mishra',
    qualification: 'All Subjects Faculty',
    subjectsLine: 'All Subjects (Maths, English, Science, SST)',
    photoFileName: 'alok.jpg',
  },
  {
    id: 'abhijeet',
    name: 'Abhijeet Mishra',
    qualification: 'All Subjects Faculty',
    subjectsLine: 'All Subjects (Maths, English, Science, SST)',
    photoFileName: 'abhijeet.jpg',
  },
];

const defaultHome: HomePageConfig = {
  coachingName: 'Pandit Maths Classes',
  tagline: 'Where Numbers Transform into Dreams',
  phoneNumbers: ['9244871784', '9755874248', '7610784561'],
  email: 'panditmathsclasses@gmail.com',
  address: 'Behind Sneha Petrol Pump',
  logoFileName: 'logo.jpg',
  heroTitle: 'Building Strong Foundations for Future Success',
  heroSubtitle: 'Specialized coaching for Classes 5-10 and entrance exams like Sainik School & Navodaya.',
};

export default function TeacherPortal({ onBack }: TeacherPortalProps) {
  const [teacherId, setTeacherId] = useState('');
  const [teacherPassword, setTeacherPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const [students, setStudents] = useState<Student[]>([]);
  const [parents, setParents] = useState<Parent[]>([]);
  const [teachers, setTeachers] = useState<TeacherInfo[]>(defaultTeachers);
  const [homePageConfig, setHomePageConfig] = useState<HomePageConfig>(defaultHome);

  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentClass, setNewStudentClass] = useState('7');
  const [customUsername, setCustomUsername] = useState('');
  const [customPassword, setCustomPassword] = useState('');
  const [isCoachingStudent, setIsCoachingStudent] = useState(true);

  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const [selectedStudentUsername, setSelectedStudentUsername] = useState('');
  const [parentCustomUsername, setParentCustomUsername] = useState('');
  const [parentCustomPassword, setParentCustomPassword] = useState('');
  const [parentName, setParentName] = useState('');
  const [parentPhone, setParentPhone] = useState('');

  const [newTeacherName, setNewTeacherName] = useState('');
  const [newTeacherQualification, setNewTeacherQualification] = useState('All Subjects Faculty');
  const [newTeacherSubjects, setNewTeacherSubjects] = useState('All Subjects (Maths, English, Science, SST)');
  const [newTeacherPhotoName, setNewTeacherPhotoName] = useState('');
  const [newTeacherPhotoData, setNewTeacherPhotoData] = useState<string | undefined>(undefined);

  const [editingTeacherId, setEditingTeacherId] = useState<string | null>(null);
  const [editingTeacher, setEditingTeacher] = useState<TeacherInfo | null>(null);

  useEffect(() => {
    if (!isLoggedIn) return;

    const loadData = async () => {
      const localStudents = localStorage.getItem('pandit_students');
      const localParents = localStorage.getItem('pandit_parents');
      const localTeachers = localStorage.getItem('pandit_teachers');
      const localHome = localStorage.getItem('pandit_homepage_config');

      if (localStudents) setStudents(JSON.parse(localStudents));
      if (localParents) setParents(JSON.parse(localParents));
      if (localTeachers) setTeachers(JSON.parse(localTeachers));
      if (localHome) setHomePageConfig(JSON.parse(localHome));

      const [fbStudents, fbParents, fbTeachers, fbHome] = await Promise.all([
        getAllStudentsFromFirebase(),
        getAllParentsFromFirebase(),
        getTeachersFromFirebase(),
        getHomePageDataFromFirebase(),
      ]);

      if (fbStudents.length > 0) setStudents(fbStudents as Student[]);
      if (fbParents.length > 0) setParents(fbParents as Parent[]);
      if (fbTeachers.length > 0) setTeachers(fbTeachers as TeacherInfo[]);
      if (fbHome) setHomePageConfig(fbHome as HomePageConfig);
    };

    loadData();
  }, [isLoggedIn]);

  useEffect(() => {
    localStorage.setItem('pandit_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('pandit_parents', JSON.stringify(parents));
  }, [parents]);

  useEffect(() => {
    localStorage.setItem('pandit_teachers', JSON.stringify(teachers));
  }, [teachers]);

  useEffect(() => {
    localStorage.setItem('pandit_homepage_config', JSON.stringify(homePageConfig));
  }, [homePageConfig]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (teacherId === 'AM2006' && teacherPassword === '@sk122aa') {
      setIsLoggedIn(true);
      setTeacherId('');
      setTeacherPassword('');
      return;
    }
    alert('Invalid Teacher ID or Password');
  };

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim() || !customUsername.trim() || !customPassword.trim()) {
      alert('Please fill all student fields.');
      return;
    }
    if (students.some((s) => s.username === customUsername.trim())) {
      alert('This student username already exists.');
      return;
    }

    const student: Student = {
      id: Date.now().toString(),
      name: newStudentName.trim(),
      class: newStudentClass,
      username: customUsername.trim(),
      password: customPassword.trim(),
      purchasedMaterials: [],
      isCoachingStudent,
    };

    const next = [...students, student];
    setStudents(next);
    await saveStudentToFirebase(student);

    setNewStudentName('');
    setNewStudentClass('7');
    setCustomUsername('');
    setCustomPassword('');
    setIsCoachingStudent(true);
    alert('Student added successfully.');
  };

  const startEditStudent = (student: Student) => {
    setEditingStudentId(student.id);
    setEditingStudent({ ...student });
  };

  const saveEditedStudent = async () => {
    if (!editingStudent) return;
    if (
      students.some(
        (s) => s.username === editingStudent.username && s.id !== editingStudent.id,
      )
    ) {
      alert('Username already used by another student.');
      return;
    }
    const next = students.map((s) => (s.id === editingStudent.id ? editingStudent : s));
    setStudents(next);
    await saveStudentToFirebase(editingStudent);
    setEditingStudentId(null);
    setEditingStudent(null);
    alert('Student updated successfully.');
  };

  const handleDeleteStudent = async (student: Student) => {
    if (!confirm('Delete this student?')) return;
    setStudents(students.filter((s) => s.id !== student.id));
    alert('Student deleted from list.');
  };

  const handleAddParent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentUsername || !parentCustomUsername || !parentCustomPassword || !parentName || !parentPhone) {
      alert('Please fill all parent fields.');
      return;
    }
    if (parents.some((p) => p.parentUsername === parentCustomUsername.trim())) {
      alert('This parent username already exists.');
      return;
    }

    const linkedStudent = students.find((s) => s.username === selectedStudentUsername);
    if (!linkedStudent) {
      alert('Selected student not found.');
      return;
    }

    const parent: Parent = {
      id: Date.now().toString(),
      parentId: parentCustomUsername.trim(),
      parentUsername: parentCustomUsername.trim(),
      parentPassword: parentCustomPassword.trim(),
      studentUsername: linkedStudent.username,
      studentName: linkedStudent.name,
      studentClass: linkedStudent.class,
      parentName: parentName.trim(),
      parentPhone: parentPhone.trim(),
    };

    const next = [...parents, parent];
    setParents(next);
    await saveParentToFirebase(parent);

    setSelectedStudentUsername('');
    setParentCustomUsername('');
    setParentCustomPassword('');
    setParentName('');
    setParentPhone('');
    alert('Parent ID created successfully.');
  };

  const handleAddTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeacherName.trim()) {
      alert('Teacher name is required.');
      return;
    }
    const teacher: TeacherInfo = {
      id: `${Date.now()}`,
      name: newTeacherName.trim(),
      qualification: newTeacherQualification.trim(),
      subjectsLine: newTeacherSubjects.trim(),
      photoFileName: newTeacherPhotoName.trim() || 'teacher.jpg',
      photoDataUrl: newTeacherPhotoData,
    };
    const next = [...teachers, teacher];
    setTeachers(next);
    await saveTeacherToFirebase(teacher);

    setNewTeacherName('');
    setNewTeacherQualification('All Subjects Faculty');
    setNewTeacherSubjects('All Subjects (Maths, English, Science, SST)');
    setNewTeacherPhotoName('');
    setNewTeacherPhotoData(undefined);
    alert('New teacher added.');
  };

  const startEditTeacher = (teacher: TeacherInfo) => {
    setEditingTeacherId(teacher.id);
    setEditingTeacher({ ...teacher });
  };

  const saveEditedTeacher = async () => {
    if (!editingTeacher) return;
    const next = teachers.map((t) => (t.id === editingTeacher.id ? editingTeacher : t));
    setTeachers(next);
    await saveTeacherToFirebase(editingTeacher);
    setEditingTeacherId(null);
    setEditingTeacher(null);
    alert('Teacher updated.');
  };

  const handleDeleteTeacher = async (teacherIdToDelete: string) => {
    if (!confirm('Delete this teacher?')) return;
    setTeachers(teachers.filter((t) => t.id !== teacherIdToDelete));
    alert('Teacher removed from list.');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setHomePageConfig({ ...homePageConfig, logoDataUrl: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleSaveHomePage = async () => {
    await saveHomePageDataToFirebase(homePageConfig);
    alert('Home page saved.');
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-10 px-4">
        <div className="max-w-md mx-auto">
          <button onClick={onBack} className="mb-6 text-blue-600 hover:text-blue-800 text-sm font-medium">
            Back to Home
          </button>
          <div className="bg-white shadow-xl rounded-2xl p-8">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Teacher Portal Login</h1>
            <p className="text-gray-600 mb-6 text-sm">Use your teacher ID and password to manage students.</p>
            <form onSubmit={handleLogin} className="space-y-4">
              <input
                type="text"
                value={teacherId}
                onChange={(e) => setTeacherId(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="Teacher ID"
                required
              />
              <input
                type="password"
                value={teacherPassword}
                onChange={(e) => setTeacherPassword(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                placeholder="Password"
                required
              />
              <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold">
                Login as Teacher
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button onClick={onBack} className="text-blue-600 text-sm font-medium">Back</button>
            <Users className="h-6 w-6 text-blue-600" />
            <h1 className="text-lg md:text-xl font-bold text-gray-900">Teacher Portal</h1>
          </div>
          <button onClick={() => setIsLoggedIn(false)} className="flex items-center space-x-1 text-red-600 bg-red-50 px-3 py-1 rounded-lg text-sm">
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        <section className="bg-white rounded-xl shadow-md p-5 border border-dashed border-green-300 bg-green-50">
          <h2 className="flex items-center text-lg font-bold text-gray-900 mb-3">
            <UserPlus className="h-5 w-5 text-green-600 mr-2" /> Add New Student
          </h2>
          <form onSubmit={handleAddStudent} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Student name" value={newStudentName} onChange={(e) => setNewStudentName(e.target.value)} required />
            <select className="px-3 py-2 border rounded-lg text-sm" value={newStudentClass} onChange={(e) => setNewStudentClass(e.target.value)}>
              <option value="7">Class 7</option><option value="8">Class 8</option><option value="9">Class 9</option><option value="10">Class 10</option>
            </select>
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Username" value={customUsername} onChange={(e) => setCustomUsername(e.target.value)} required />
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Password" value={customPassword} onChange={(e) => setCustomPassword(e.target.value)} required />
            <div>
              <label className="flex items-center text-xs mb-2"><input type="checkbox" className="mr-2" checked={isCoachingStudent} onChange={(e) => setIsCoachingStudent(e.target.checked)} /> Coaching Student</label>
              <button type="submit" className="w-full bg-green-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">Save Student</button>
            </div>
          </form>
        </section>

        <section className="bg-white rounded-xl shadow-md p-5">
          <h2 className="text-lg font-bold text-gray-900 mb-3">All Students ({students.length})</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="text-left py-2 px-3">Name</th>
                  <th className="text-left py-2 px-3">Class</th>
                  <th className="text-left py-2 px-3">Username</th>
                  <th className="text-left py-2 px-3">Password</th>
                  <th className="text-left py-2 px-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <tr key={student.id} className="border-b">
                    <td className="py-2 px-3">{student.name}</td>
                    <td className="py-2 px-3">{student.class}</td>
                    <td className="py-2 px-3 font-mono text-blue-700">{student.username}</td>
                    <td className="py-2 px-3 font-mono text-red-600">{student.password}</td>
                    <td className="py-2 px-3">
                      <button onClick={() => startEditStudent(student)} className="text-blue-600 mr-3 inline-flex items-center"><Pencil className="h-4 w-4 mr-1" />Edit</button>
                      <button onClick={() => handleDeleteStudent(student)} className="text-red-600 inline-flex items-center"><Trash2 className="h-4 w-4 mr-1" />Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {editingStudentId && editingStudent && (
            <div className="mt-4 p-4 rounded-lg border bg-blue-50">
              <h3 className="font-semibold mb-2">Edit Student</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
                <input className="px-3 py-2 border rounded" value={editingStudent.name} onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })} />
                <input className="px-3 py-2 border rounded" value={editingStudent.class} onChange={(e) => setEditingStudent({ ...editingStudent, class: e.target.value })} />
                <input className="px-3 py-2 border rounded" value={editingStudent.username} onChange={(e) => setEditingStudent({ ...editingStudent, username: e.target.value })} />
                <input className="px-3 py-2 border rounded" value={editingStudent.password} onChange={(e) => setEditingStudent({ ...editingStudent, password: e.target.value })} />
              </div>
              <div className="mt-3 space-x-2">
                <button onClick={saveEditedStudent} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm">Save Changes</button>
                <button onClick={() => { setEditingStudentId(null); setEditingStudent(null); }} className="px-4 py-2 bg-gray-200 rounded-lg text-sm">Cancel</button>
              </div>
            </div>
          )}
        </section>

        <section className="bg-white rounded-xl shadow-md p-5 border border-dashed border-purple-300 bg-purple-50">
          <h2 className="flex items-center text-lg font-bold text-gray-900 mb-3"><UserCheck className="h-5 w-5 text-purple-600 mr-2" />Generate Parent ID</h2>
          <form onSubmit={handleAddParent} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3 items-end">
            <select className="px-3 py-2 border rounded-lg text-sm" value={selectedStudentUsername} onChange={(e) => setSelectedStudentUsername(e.target.value)} required>
              <option value="">Select Student</option>
              {students.map((s) => <option key={s.id} value={s.username}>{s.name} ({s.class})</option>)}
            </select>
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Parent Name" value={parentName} onChange={(e) => setParentName(e.target.value)} required />
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Parent Phone" value={parentPhone} onChange={(e) => setParentPhone(e.target.value)} required />
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Parent Username" value={parentCustomUsername} onChange={(e) => setParentCustomUsername(e.target.value)} required />
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Parent Password" value={parentCustomPassword} onChange={(e) => setParentCustomPassword(e.target.value)} required />
            <button type="submit" className="bg-purple-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">Add Parent</button>
          </form>
        </section>

        <section className="bg-white rounded-xl shadow-md p-5 border border-dashed border-cyan-300 bg-cyan-50">
          <h2 className="flex items-center text-lg font-bold text-gray-900 mb-3"><Users className="h-5 w-5 text-cyan-700 mr-2" />Add New Teacher</h2>
          <form onSubmit={handleAddTeacher} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Teacher Name" value={newTeacherName} onChange={(e) => setNewTeacherName(e.target.value)} required />
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Qualification" value={newTeacherQualification} onChange={(e) => setNewTeacherQualification(e.target.value)} />
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Subjects line" value={newTeacherSubjects} onChange={(e) => setNewTeacherSubjects(e.target.value)} />
            <input className="px-3 py-2 border rounded-lg text-sm" placeholder="Photo file name (e.g. alok.jpg)" value={newTeacherPhotoName} onChange={(e) => setNewTeacherPhotoName(e.target.value)} />
            <div>
              <input type="file" accept="image/*" className="mb-2 w-full text-xs" onChange={(e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onloadend = () => setNewTeacherPhotoData(reader.result as string);
                reader.readAsDataURL(file);
              }} />
              <button type="submit" className="w-full bg-cyan-700 text-white px-3 py-2 rounded-lg text-sm font-semibold">Save Teacher</button>
            </div>
          </form>
        </section>

        <section className="bg-white rounded-xl shadow-md p-5">
          <h2 className="text-lg font-bold text-gray-900 mb-3">All Teachers ({teachers.length})</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="text-left py-2 px-3">Name</th>
                  <th className="text-left py-2 px-3">Qualification</th>
                  <th className="text-left py-2 px-3">Subjects</th>
                  <th className="text-left py-2 px-3">Photo</th>
                  <th className="text-left py-2 px-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {teachers.map((teacher) => (
                  <tr key={teacher.id} className="border-b">
                    <td className="py-2 px-3">{teacher.name}</td>
                    <td className="py-2 px-3">{teacher.qualification}</td>
                    <td className="py-2 px-3">{teacher.subjectsLine}</td>
                    <td className="py-2 px-3">{teacher.photoFileName}</td>
                    <td className="py-2 px-3">
                      <button onClick={() => startEditTeacher(teacher)} className="text-blue-600 mr-3 inline-flex items-center"><Pencil className="h-4 w-4 mr-1" />Edit</button>
                      <button onClick={() => handleDeleteTeacher(teacher.id)} className="text-red-600 inline-flex items-center"><Trash2 className="h-4 w-4 mr-1" />Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {editingTeacherId && editingTeacher && (
            <div className="mt-4 p-4 rounded-lg border bg-cyan-50">
              <h3 className="font-semibold mb-2">Edit Teacher</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
                <input className="px-3 py-2 border rounded" value={editingTeacher.name} onChange={(e) => setEditingTeacher({ ...editingTeacher, name: e.target.value })} />
                <input className="px-3 py-2 border rounded" value={editingTeacher.qualification} onChange={(e) => setEditingTeacher({ ...editingTeacher, qualification: e.target.value })} />
                <input className="px-3 py-2 border rounded" value={editingTeacher.subjectsLine} onChange={(e) => setEditingTeacher({ ...editingTeacher, subjectsLine: e.target.value })} />
                <input className="px-3 py-2 border rounded" value={editingTeacher.photoFileName} onChange={(e) => setEditingTeacher({ ...editingTeacher, photoFileName: e.target.value })} />
              </div>
              <div className="mt-3 space-x-2">
                <button onClick={saveEditedTeacher} className="px-4 py-2 bg-cyan-700 text-white rounded-lg text-sm">Save Changes</button>
                <button onClick={() => { setEditingTeacherId(null); setEditingTeacher(null); }} className="px-4 py-2 bg-gray-200 rounded-lg text-sm">Cancel</button>
              </div>
            </div>
          )}
        </section>

        <section className="bg-white rounded-xl shadow-md p-5 border border-dashed border-green-300 bg-green-50">
          <h2 className="flex items-center text-lg font-bold text-gray-900 mb-3"><BookOpen className="h-5 w-5 text-green-600 mr-2" />Edit Home Page</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.coachingName} onChange={(e) => setHomePageConfig({ ...homePageConfig, coachingName: e.target.value })} placeholder="Coaching Name" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.tagline} onChange={(e) => setHomePageConfig({ ...homePageConfig, tagline: e.target.value })} placeholder="Tagline" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.email} onChange={(e) => setHomePageConfig({ ...homePageConfig, email: e.target.value })} placeholder="Email" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.address} onChange={(e) => setHomePageConfig({ ...homePageConfig, address: e.target.value })} placeholder="Address" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.heroTitle || ''} onChange={(e) => setHomePageConfig({ ...homePageConfig, heroTitle: e.target.value })} placeholder="Hero Title" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.heroSubtitle || ''} onChange={(e) => setHomePageConfig({ ...homePageConfig, heroSubtitle: e.target.value })} placeholder="Hero Subtitle" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.phoneNumbers[0] || ''} onChange={(e) => setHomePageConfig({ ...homePageConfig, phoneNumbers: [e.target.value, homePageConfig.phoneNumbers[1] || '', homePageConfig.phoneNumbers[2] || ''] })} placeholder="Phone 1" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.phoneNumbers[1] || ''} onChange={(e) => setHomePageConfig({ ...homePageConfig, phoneNumbers: [homePageConfig.phoneNumbers[0] || '', e.target.value, homePageConfig.phoneNumbers[2] || ''] })} placeholder="Phone 2" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.phoneNumbers[2] || ''} onChange={(e) => setHomePageConfig({ ...homePageConfig, phoneNumbers: [homePageConfig.phoneNumbers[0] || '', homePageConfig.phoneNumbers[1] || '', e.target.value] })} placeholder="Phone 3" />
            <input className="px-3 py-2 border rounded-lg text-sm" value={homePageConfig.logoFileName || ''} onChange={(e) => setHomePageConfig({ ...homePageConfig, logoFileName: e.target.value })} placeholder="Logo file name" />
            <input type="file" accept="image/*" className="px-3 py-2 border rounded-lg text-sm md:col-span-2" onChange={handleLogoUpload} />
          </div>
          <button onClick={handleSaveHomePage} className="mt-4 bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-semibold">Save Changes</button>
        </section>
      </main>
    </div>
  );
}
