import React, { useState, useEffect } from 'react';
import { 
  PlusCircle, 
  Trash2, 
  Calendar, 
  User, 
  BookText, 
  ChevronRight,
  ClipboardList,
  ArrowLeft
} from 'lucide-react';

interface Homework {
  id: string;
  class: string;
  subject: string;
  title: string;
  description: string;
  dueDate: string;
  createdAt: string;
}

const HomeworkPortal = ({ onBack }: { onBack: () => void }) => {
  const [homeworks, setHomeworks] = useState<Homework[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [selectedClass, setSelectedClass] = useState<string>('All');
  
  // Login Form State
  const [loginData, setLoginData] = useState({
    teacherId: '',
    password: ''
  });
  const [loginError, setLoginError] = useState('');

  // Form State
  const [newHomework, setNewHomework] = useState({
    class: '7th',
    subject: 'Maths',
    title: '',
    description: '',
    dueDate: new Date().toISOString().split('T')[0]
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginData.teacherId === 'AM2006' && loginData.password === '@sk122aa') {
      setIsAdmin(true);
      setShowLoginForm(false);
      setLoginError('');
      setLoginData({ teacherId: '', password: '' });
    } else {
      setLoginError('Invalid Teacher ID or Password. Please try again.');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    setShowAddForm(false);
  };

  // Load homework from localStorage on mount
  useEffect(() => {
    const savedHomework = localStorage.getItem('pandit_homework');
    if (savedHomework) {
      setHomeworks(JSON.parse(savedHomework));
    }
  }, []);

  // Save homework to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('pandit_homework', JSON.stringify(homeworks));
  }, [homeworks]);

  const handleAddHomework = (e: React.FormEvent) => {
    e.preventDefault();
    const homework: Homework = {
      id: Date.now().toString(),
      ...newHomework,
      createdAt: new Date().toLocaleDateString()
    };
    setHomeworks([homework, ...homeworks]);
    setNewHomework({
      class: '7th',
      subject: 'Maths',
      title: '',
      description: '',
      dueDate: new Date().toISOString().split('T')[0]
    });
    setShowAddForm(false);
  };

  const deleteHomework = (id: string) => {
    if (window.confirm('Are you sure you want to delete this homework?')) {
      setHomeworks(homeworks.filter(h => h.id !== id));
    }
  };

  const filteredHomeworks = selectedClass === 'All' 
    ? homeworks 
    : homeworks.filter(h => h.class === selectedClass);

  const classes = ['7th', '8th', '9th', '10th'];
  const subjects = ['Maths', 'Science', 'English', 'SST'];

  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      {/* Header */}
      <nav className="bg-indigo-700 text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <button 
              onClick={onBack}
              className="flex items-center gap-2 hover:bg-indigo-600 px-3 py-1 rounded transition"
            >
              <ArrowLeft size={20} />
              <span>Back to Main Site</span>
            </button>
            <div className="flex items-center gap-2">
              <ClipboardList className="text-white" />
              <h1 className="text-xl font-bold">Pandit Homework Portal</h1>
            </div>
            <button 
              onClick={() => isAdmin ? handleLogout() : setShowLoginForm(true)}
              className={`px-4 py-1 rounded-full text-sm font-medium transition ${
                isAdmin ? 'bg-red-500 hover:bg-red-600' : 'bg-white text-indigo-700 hover:bg-gray-100'
              }`}
            >
              {isAdmin ? 'Logout' : 'Teacher Login'}
            </button>
          </div>
        </div>
      </nav>

      {/* Teacher Login Modal */}
      {showLoginForm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="bg-indigo-600 p-6 text-white text-center">
              <h2 className="text-2xl font-bold">Teacher Login</h2>
              <p className="text-indigo-100 mt-1">Access Homework Portal Management</p>
            </div>
            <form onSubmit={handleLogin} className="p-8 space-y-6">
              {loginError && (
                <div className="bg-red-50 border-l-4 border-red-500 p-4 text-red-700 text-sm">
                  {loginError}
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Teacher ID</label>
                <input 
                  type="text" 
                  required
                  placeholder="Enter your ID"
                  value={loginData.teacherId}
                  onChange={(e) => setLoginData({...loginData, teacherId: e.target.value})}
                  className="w-full border-gray-300 border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none transition"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input 
                  type="password" 
                  required
                  placeholder="Enter your password"
                  value={loginData.password}
                  onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                  className="w-full border-gray-300 border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none transition"
                />
              </div>
              <div className="flex gap-4">
                <button 
                  type="button"
                  onClick={() => {
                    setShowLoginForm(false);
                    setLoginError('');
                    setLoginData({ teacherId: '', password: '' });
                  }}
                  className="flex-1 px-4 py-3 bg-gray-100 text-gray-700 font-bold rounded-lg hover:bg-gray-200 transition"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-4 py-3 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition"
                >
                  Login
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="max-w-4xl mx-auto px-4 mt-8">
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Homework Dashboard</h2>
              <p className="text-gray-600">Classes 7th to 10th</p>
            </div>
            
            {isAdmin && !showAddForm && (
              <button 
                onClick={() => setShowAddForm(true)}
                className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition"
              >
                <PlusCircle size={20} />
                <span>Add New Homework</span>
              </button>
            )}
          </div>

          {/* Class Filters */}
          <div className="flex flex-wrap gap-2 mt-6">
            <button 
              onClick={() => setSelectedClass('All')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                selectedClass === 'All' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              All Classes
            </button>
            {classes.map(cls => (
              <button 
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                  selectedClass === cls ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                Class {cls}
              </button>
            ))}
          </div>
        </div>

        {/* Add Homework Form */}
        {isAdmin && showAddForm && (
          <div className="bg-white rounded-xl shadow-md p-6 mb-8 border-2 border-indigo-100 animate-in fade-in slide-in-from-top-4">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-800">Assign New Homework</h3>
              <button onClick={() => setShowAddForm(false)} className="text-gray-400 hover:text-gray-600">Cancel</button>
            </div>
            <form onSubmit={handleAddHomework} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Select Class</label>
                  <select 
                    value={newHomework.class}
                    onChange={(e) => setNewHomework({...newHomework, class: e.target.value})}
                    className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    {classes.map(c => <option key={c} value={c}>Class {c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                  <select 
                    value={newHomework.subject}
                    onChange={(e) => setNewHomework({...newHomework, subject: e.target.value})}
                    className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    {subjects.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Homework Title</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g., Algebra Exercise 2.1"
                  value={newHomework.title}
                  onChange={(e) => setNewHomework({...newHomework, title: e.target.value})}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description / Details</label>
                <textarea 
                  required
                  rows={4}
                  placeholder="Describe the homework questions here..."
                  value={newHomework.description}
                  onChange={(e) => setNewHomework({...newHomework, description: e.target.value})}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                <input 
                  type="date" 
                  required
                  value={newHomework.dueDate}
                  onChange={(e) => setNewHomework({...newHomework, dueDate: e.target.value})}
                  className="w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <button 
                type="submit"
                className="w-full bg-indigo-600 text-white font-bold py-3 rounded-lg hover:bg-indigo-700 transition"
              >
                Post Homework
              </button>
            </form>
          </div>
        )}

        {/* Homework List */}
        <div className="space-y-6">
          {filteredHomeworks.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-xl border-2 border-dashed border-gray-200">
              <BookText className="mx-auto text-gray-300 mb-4" size={48} />
              <p className="text-gray-500 text-lg">No homework assigned yet for this class.</p>
            </div>
          ) : (
            filteredHomeworks.map((hw) => (
              <div key={hw.id} className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition group">
                <div className="flex">
                  <div className={`w-2 ${
                    hw.class === '10th' ? 'bg-red-500' : 
                    hw.class === '9th' ? 'bg-orange-500' : 
                    hw.class === '8th' ? 'bg-green-500' : 'bg-blue-500'
                  }`}></div>
                  <div className="flex-1 p-6">
                    <div className="flex flex-wrap justify-between items-start gap-4 mb-4">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <span className={`text-xs font-bold px-2 py-1 rounded uppercase tracking-wider ${
                            hw.class === '10th' ? 'bg-red-100 text-red-700' : 
                            hw.class === '9th' ? 'bg-orange-100 text-orange-700' : 
                            hw.class === '8th' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                          }`}>
                            Class {hw.class}
                          </span>
                          <span className="text-xs font-bold px-2 py-1 rounded bg-indigo-100 text-indigo-700 uppercase tracking-wider">
                            {hw.subject}
                          </span>
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 group-hover:text-indigo-600 transition">{hw.title}</h3>
                      </div>
                      
                      {isAdmin && (
                        <button 
                          onClick={() => deleteHomework(hw.id)}
                          className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition"
                          title="Delete"
                        >
                          <Trash2 size={20} />
                        </button>
                      )}
                    </div>
                    
                    <p className="text-gray-600 mb-6 whitespace-pre-wrap leading-relaxed">{hw.description}</p>
                    
                    <div className="flex flex-wrap items-center gap-6 text-sm text-gray-500 pt-4 border-t border-gray-50">
                      <div className="flex items-center gap-2">
                        <Calendar size={16} />
                        <span>Assigned: {hw.createdAt}</span>
                      </div>
                      <div className="flex items-center gap-2 text-red-600 font-medium">
                        <Calendar size={16} />
                        <span>Due Date: {new Date(hw.dueDate).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <User size={16} />
                        <span>By: Pandit Sir</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Admin Quick Tips */}
      {isAdmin && (
        <div className="max-w-4xl mx-auto px-4 mt-8">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex gap-4">
            <div className="bg-yellow-100 p-2 rounded-full h-fit">
              <ChevronRight className="text-yellow-600" />
            </div>
            <div>
              <p className="font-bold text-yellow-800">Teacher Tips:</p>
              <ul className="text-sm text-yellow-700 list-disc list-inside mt-1">
                <li>Homework is saved on this browser's memory.</li>
                <li>Make sure to set clear due dates.</li>
                <li>You can delete old homework once it's completed.</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HomeworkPortal;
