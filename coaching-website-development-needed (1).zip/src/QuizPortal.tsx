import { useState, useEffect } from 'react';
import { Target, LogOut, PlusCircle, CheckCircle } from 'lucide-react';

export default function QuizPortal({ onBack }: { onBack: () => void }) {
  const [activeTab, setActiveTab] = useState<'home' | 'login' | 'take_quiz'>('login');
  const [session, setSession] = useState<{isLoggedIn: boolean; userType: 'teacher' | 'student' | null; userId?: string; userName?: string}>({ isLoggedIn: false, userType: null });
  const [loginType, setLoginType] = useState<'teacher' | 'student'>('teacher');
  
  const [teacherId, setTeacherId] = useState('');
  const [teacherPassword, setTeacherPassword] = useState('');
  const [studentUsername, setStudentUsername] = useState('');
  const [studentPassword, setStudentPassword] = useState('');

  const [students] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_students');
    return saved ? JSON.parse(saved) : [];
  });

  const [quizzes, setQuizzes] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_quizzes');
    return saved ? JSON.parse(saved) : [];
  });

  const [quizResults, setQuizResults] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_quiz_results');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('pandit_quizzes', JSON.stringify(quizzes));
  }, [quizzes]);

  useEffect(() => {
    localStorage.setItem('pandit_quiz_results', JSON.stringify(quizResults));
  }, [quizResults]);

  const handleTeacherLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (teacherId === 'AM2006' && teacherPassword === '@sk122aa') {
      setSession({ isLoggedIn: true, userType: 'teacher', userId: 'teacher', userName: 'Pandit Sir' });
      setActiveTab('home');
    } else alert('Invalid Teacher Credentials');
  };

  const handleStudentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const student = students.find(s => s.username === studentUsername && s.password === studentPassword);
    if (student) {
      setSession({ isLoggedIn: true, userType: 'student', userId: student.id, userName: student.name });
      setActiveTab('home');
    } else alert('Invalid Student Credentials');
  };

  // Quiz Builder
  const [newQuiz, setNewQuiz] = useState({ title: '', class: '7', subject: 'Maths', questions: [] as any[] });
  const [currentQ, setCurrentQ] = useState({ q: '', options: ['', '', '', ''], correct: 0 });

  const addQuestion = () => {
    if(!currentQ.q || currentQ.options.some(o => !o)) return alert("Please fill question and all options");
    setNewQuiz({...newQuiz, questions: [...newQuiz.questions, currentQ]});
    setCurrentQ({ q: '', options: ['', '', '', ''], correct: 0 });
  };

  const saveQuiz = () => {
    if(newQuiz.questions.length === 0) return alert("Add at least one question!");
    const qz = { id: Date.now().toString(), ...newQuiz, date: new Date().toISOString().split('T')[0] };
    setQuizzes([...quizzes, qz]);
    setNewQuiz({ title: '', class: '7', subject: 'Maths', questions: [] });
    alert("Quiz created!");
  };

  // Student Taking Quiz
  const [activeQuiz, setActiveQuiz] = useState<any>(null);
  const [answers, setAnswers] = useState<number[]>([]);

  const startQuiz = (q: any) => {
    setActiveQuiz(q);
    setAnswers(new Array(q.questions.length).fill(-1));
    setActiveTab('take_quiz');
  };

  const submitQuiz = () => {
    let score = 0;
    activeQuiz.questions.forEach((q: any, idx: number) => {
      if(answers[idx] === q.correct) score++;
    });
    
    const result = {
      id: Date.now().toString(),
      quizId: activeQuiz.id,
      quizTitle: activeQuiz.title,
      studentId: session.userId,
      score,
      total: activeQuiz.questions.length,
      date: new Date().toISOString().split('T')[0]
    };

    setQuizResults([...quizResults, result]);
    alert(`Quiz Submitted! You scored ${score} out of ${activeQuiz.questions.length}`);
    setActiveQuiz(null);
    setActiveTab('home');
  };

  const renderLogin = () => (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-lg p-8">
        <button onClick={onBack} className="mb-6 text-blue-600 hover:underline">← Back to Home</button>
        <h2 className="text-2xl font-bold mb-6 text-center">Online Test Portal</h2>
        <div className="flex mb-6 bg-gray-100 rounded p-1">
          <button onClick={() => setLoginType('teacher')} className={`flex-1 py-2 rounded text-sm font-medium ${loginType === 'teacher' ? 'bg-white shadow' : ''}`}>Teacher</button>
          <button onClick={() => setLoginType('student')} className={`flex-1 py-2 rounded text-sm font-medium ${loginType === 'student' ? 'bg-white shadow' : ''}`}>Student</button>
        </div>
        {loginType === 'teacher' ? (
          <form onSubmit={handleTeacherLogin} className="space-y-4">
            <input type="text" placeholder="Teacher ID" value={teacherId} onChange={e => setTeacherId(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <input type="password" placeholder="Password" value={teacherPassword} onChange={e => setTeacherPassword(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg">Login</button>
          </form>
        ) : (
          <form onSubmit={handleStudentLogin} className="space-y-4">
            <input type="text" placeholder="Username" value={studentUsername} onChange={e => setStudentUsername(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <input type="password" placeholder="Password" value={studentPassword} onChange={e => setStudentPassword(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg">Login</button>
          </form>
        )}
      </div>
    </div>
  );

  const renderTeacherPortal = () => (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Create Online Test/Quiz</h2>
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold text-lg mb-4 flex items-center"><PlusCircle className="mr-2" /> New Quiz Details</h3>
          <div className="space-y-4">
            <input type="text" placeholder="Quiz Title (e.g. Algebra Test)" value={newQuiz.title} onChange={e => setNewQuiz({...newQuiz, title: e.target.value})} className="w-full px-4 py-2 border rounded" />
            <div className="flex space-x-4">
              <select value={newQuiz.class} onChange={e => setNewQuiz({...newQuiz, class: e.target.value})} className="w-1/2 px-4 py-2 border rounded">
                {[7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
              </select>
              <select value={newQuiz.subject} onChange={e => setNewQuiz({...newQuiz, subject: e.target.value})} className="w-1/2 px-4 py-2 border rounded">
                <option value="Maths">Maths</option><option value="Science">Science</option><option value="English">English</option><option value="SST">SST</option>
              </select>
            </div>
            
            <div className="border-t pt-4">
              <h4 className="font-medium mb-2">Add Question ({newQuiz.questions.length} added)</h4>
              <textarea placeholder="Question Text" value={currentQ.q} onChange={e => setCurrentQ({...currentQ, q: e.target.value})} className="w-full px-4 py-2 border rounded mb-2" rows={2}/>
              {currentQ.options.map((opt, i) => (
                <div key={i} className="flex items-center mb-2 space-x-2">
                  <input type="radio" checked={currentQ.correct === i} onChange={() => setCurrentQ({...currentQ, correct: i})} />
                  <input type="text" placeholder={`Option ${i+1}`} value={opt} onChange={e => { const newOpts = [...currentQ.options]; newOpts[i] = e.target.value; setCurrentQ({...currentQ, options: newOpts})}} className="flex-1 px-3 py-1 border rounded" />
                </div>
              ))}
              <button onClick={addQuestion} className="bg-gray-200 px-4 py-2 rounded text-sm hover:bg-gray-300">Add Question to Quiz</button>
            </div>
            
            <button onClick={saveQuiz} className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 mt-4">Save & Publish Quiz</button>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold text-lg mb-4">Published Quizzes</h3>
          {quizzes.length === 0 ? <p className="text-gray-500">No quizzes published.</p> : (
            <ul className="space-y-4">
              {quizzes.slice().reverse().map(q => (
                <li key={q.id} className="border p-4 rounded bg-gray-50">
                  <h4 className="font-bold">{q.title}</h4>
                  <p className="text-sm text-gray-600">Class {q.class} • {q.subject} • {q.questions.length} Questions</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );

  const renderStudentPortal = () => {
    const studentClass = students.find(s => s.id === session.userId)?.class;
    const availableQuizzes = quizzes.filter(q => q.class === studentClass);

    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-6">Available Tests</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="font-semibold text-lg mb-4">Take a Test</h3>
            {availableQuizzes.length === 0 ? <p className="text-gray-500">No tests available for your class.</p> : (
              <ul className="space-y-4">
                {availableQuizzes.map(q => {
                  const alreadyTaken = quizResults.find(r => r.quizId === q.id && r.studentId === session.userId);
                  return (
                    <li key={q.id} className="border p-4 rounded flex justify-between items-center bg-gray-50">
                      <div>
                        <h4 className="font-bold">{q.title}</h4>
                        <p className="text-sm text-gray-600">{q.subject} • {q.questions.length} Questions</p>
                      </div>
                      {alreadyTaken ? (
                        <span className="text-green-600 font-semibold flex items-center"><CheckCircle className="w-4 h-4 mr-1"/> Done: {alreadyTaken.score}/{alreadyTaken.total}</span>
                      ) : (
                        <button onClick={() => startQuiz(q)} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Start Test</button>
                      )}
                    </li>
                  )
                })}
              </ul>
            )}
          </div>
          <div className="bg-white rounded-xl shadow p-6">
             <h3 className="font-semibold text-lg mb-4">My Results</h3>
             {quizResults.filter(r => r.studentId === session.userId).length === 0 ? <p className="text-gray-500">No tests taken yet.</p> : (
               <ul className="space-y-3">
                 {quizResults.filter(r => r.studentId === session.userId).map(r => (
                   <li key={r.id} className="border-b pb-2 flex justify-between">
                     <span>{r.quizTitle}</span>
                     <span className="font-bold text-blue-600">{r.score} / {r.total}</span>
                   </li>
                 ))}
               </ul>
             )}
          </div>
        </div>
      </div>
    );
  };

  const renderTakeQuiz = () => (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="bg-white rounded-xl shadow p-8">
        <h2 className="text-2xl font-bold mb-6">{activeQuiz?.title}</h2>
        <div className="space-y-8">
          {activeQuiz?.questions.map((q: any, qIdx: number) => (
            <div key={qIdx} className="border-b pb-6">
              <p className="font-semibold mb-4 text-lg">{qIdx + 1}. {q.q}</p>
              <div className="space-y-2">
                {q.options.map((opt: string, oIdx: number) => (
                  <label key={oIdx} className={`flex items-center p-3 border rounded cursor-pointer ${answers[qIdx] === oIdx ? 'bg-blue-50 border-blue-500' : 'hover:bg-gray-50'}`}>
                    <input type="radio" name={`q-${qIdx}`} className="mr-3" checked={answers[qIdx] === oIdx} onChange={() => {
                      const newAns = [...answers];
                      newAns[qIdx] = oIdx;
                      setAnswers(newAns);
                    }}/>
                    {opt}
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>
        <button onClick={submitQuiz} className="mt-8 bg-green-600 text-white px-8 py-3 rounded-lg font-bold text-lg hover:bg-green-700 w-full">Submit Quiz</button>
      </div>
    </div>
  );

  if (activeTab === 'login') return renderLogin();
  if (activeTab === 'take_quiz') return renderTakeQuiz();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <button onClick={onBack} className="mr-4 text-blue-600 hover:underline">← Back</button>
          <Target className="w-6 h-6 text-blue-600 mr-2" />
          <h1 className="text-xl font-bold">Online Test Portal</h1>
        </div>
        <button onClick={() => setActiveTab('login')} className="flex items-center text-red-600"><LogOut className="w-4 h-4 mr-1"/> Logout</button>
      </header>
      <div className="container mx-auto">
        {session.userType === 'teacher' ? renderTeacherPortal() : renderStudentPortal()}
      </div>
    </div>
  );
}