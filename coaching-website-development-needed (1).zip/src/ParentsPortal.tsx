import { useState, useEffect } from 'react';
import { 
  Users, 
  TrendingUp, 
  CreditCard, 
  FileText,
  ChevronDown,
  ChevronUp,
  LogOut,
  User,
  GraduationCap,
  Award,
  Calendar
} from 'lucide-react';

interface Student {
  id: string;
  name: string;
  class: number;
  username: string;
  password: string;
  type: 'coaching' | 'online';
  purchasedMaterials: number;
}

interface Parent {
  id: string;
  password: string;
  name: string;
  children: string[]; // student usernames
}

// Types removed as they are dynamic

export default function ParentsPortal({ onBack }: { onBack: () => void }) {
  const [loginMode] = useState<'parent' | 'child'>('parent');
  const [parentLogin, setParentLogin] = useState({ id: '', password: '' });
  const [childLogin, setChildLogin] = useState({ username: '', password: '' });
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [selectedParent, setSelectedParent] = useState<Parent | null>(null);
  const [selectedChild, setSelectedChild] = useState<Student | null>(null);
  const [showChildDetails, setShowChildDetails] = useState(false);
  const [paymentModal, setPaymentModal] = useState<{show: boolean, studentId: string, studentName: string, month: string, amount: number} | null>(null);
  const [utrNumber, setUtrNumber] = useState('');

  // Load data from localStorage
  const [students] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_students');
    return saved ? JSON.parse(saved) : [];
  });

  const [parents] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_parents');
    return saved ? JSON.parse(saved) : [];
  });

  const [testScores] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_test_scores');
    return saved ? JSON.parse(saved) : [];
  });

  const [fees, setFees] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_fees');
    return saved ? JSON.parse(saved) : [];
  });

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('pandit_fees', JSON.stringify(fees));
  }, [fees]);

  const handleParentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const parent = parents.find(p => p.parentUsername === parentLogin.id && p.parentPassword === parentLogin.password);
    if (parent) {
      // Find all students linked to this parent username
      const linkedStudentUsernames = parents.filter(p => p.parentUsername === parent.parentUsername).map(p => p.studentUsername);
      setSelectedParent({
        id: parent.id,
        name: parent.parentName,
        password: parent.parentPassword,
        children: linkedStudentUsernames
      });
      setIsLoggedIn(true);
    } else {
      alert('Invalid Parent ID or Password');
    }
  };

  const handleChildLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const student = students.find(s => s.username === childLogin.username && s.password === childLogin.password);
    if (student) {
      setSelectedChild(student);
      setIsLoggedIn(true);
    } else {
      alert('Invalid Username or Password');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setSelectedParent(null);
    setSelectedChild(null);
    setParentLogin({ id: '', password: '' });
    setChildLogin({ username: '', password: '' });
  };

  const getStudentById = (studentId: string) => {
    return students.find(s => s.username === studentId);
  };

  const getTestScoresForStudent = (studentId: string) => {
    return testScores.filter(t => t.studentId === studentId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const getFeesForStudent = (studentId: string, currentMonth: string) => {
    // In FeePaymentPortal, month is just the string like 'March', and studentId is student.id
    return fees.filter(f => f.studentId === studentId && f.month === currentMonth);
  };

  const getCurrentMonthYear = () => {
    const date = new Date();
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return {
      month: months[date.getMonth()],
      year: date.getFullYear()
    };
  };

  const renderLogin = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <button
            onClick={onBack}
            className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6"
          >
            <ChevronDown className="h-5 w-5 rotate-90 mr-2" />
            Back to Home
          </button>
          <h1 className="text-4xl font-bold text-blue-900 mb-2">Parents Portal</h1>
          <p className="text-gray-600">Track your child's academic progress and fee status</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Parent Login */}
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-blue-100">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-blue-900">Parent Login</h2>
            </div>
            <form onSubmit={handleParentLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Parent ID</label>
                <input
                  type="text"
                  value={parentLogin.id}
                  onChange={(e) => setParentLogin({ ...parentLogin, id: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter your Parent ID"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                <input
                  type="password"
                  value={parentLogin.password}
                  onChange={(e) => setParentLogin({ ...parentLogin, password: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter your password"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Login as Parent
              </button>
            </form>
          </div>

          {/* Child Login */}
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-indigo-100">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-indigo-100 p-3 rounded-lg">
                <User className="h-6 w-6 text-indigo-600" />
              </div>
              <h2 className="text-2xl font-bold text-indigo-900">Student Login</h2>
            </div>
            <form onSubmit={handleChildLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
                <input
                  type="text"
                  value={childLogin.username}
                  onChange={(e) => setChildLogin({ ...childLogin, username: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  placeholder="Enter student username"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                <input
                  type="password"
                  value={childLogin.password}
                  onChange={(e) => setChildLogin({ ...childLogin, password: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  placeholder="Enter password"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
              >
                Login as Student
              </button>
            </form>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-gray-600">
            Don't have an ID?{' '}
            <button
              onClick={() => alert('Please contact your teacher to get a Parent ID or Student Username')}
              className="text-blue-600 hover:text-blue-800 font-semibold"
            >
              Contact Teacher
            </button>
          </p>
        </div>
      </div>
    </div>
  );

  const renderParentDashboard = () => {
    const currentMonthYear = getCurrentMonthYear();
    
    if (!selectedParent) return null;

    return (
      <div className="min-h-screen bg-gray-50 py-8 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h1 className="text-3xl font-bold text-blue-900">Welcome, {selectedParent.name}</h1>
                <p className="text-gray-600 mt-1">Monitor your children's academic progress</p>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>

          {/* Children List */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {selectedParent.children.map((childId) => {
              const child = getStudentById(childId);
              if (!child) return null;
              
              const testScores = getTestScoresForStudent(childId);
              const currentFees = getFeesForStudent(child.id, currentMonthYear.month);
              const latestFee = currentFees[0];
              const avgScore = testScores.length > 0 
                ? Math.round(testScores.reduce((sum, t) => sum + (t.score / t.total * 100), 0) / testScores.length) 
                : 0;

              return (
                <div
                  key={childId}
                  className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden cursor-pointer"
                  onClick={() => setShowChildDetails(!showChildDetails)}
                >
                  <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center space-x-2 mb-2">
                          <GraduationCap className="h-5 w-5 text-white" />
                          <span className="text-white font-semibold">{child.class}th Std</span>
                        </div>
                        <h3 className="text-2xl font-bold text-white">{child.name}</h3>
                      </div>
                      <div className="text-white">
                        {showChildDetails ? <ChevronUp className="h-6 w-6" /> : <ChevronDown className="h-6 w-6" />}
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <TrendingUp className="h-5 w-5 text-blue-600 mx-auto mb-1" />
                        <div className="text-2xl font-bold text-blue-900">{avgScore}%</div>
                        <div className="text-xs text-gray-600">Avg Performance</div>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <CreditCard className="h-5 w-5 text-green-600 mx-auto mb-1" />
                        <div className="text-2xl font-bold text-green-900">{latestFee ? '✓' : '✗'}</div>
                        <div className="text-xs text-gray-600">{latestFee ? 'Paid' : 'Pending'}</div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Child Details (Expanded) */}
          {showChildDetails && selectedParent.children.map((childId) => {
            const child = getStudentById(childId);
            if (!child) return null;

            const testScores = getTestScoresForStudent(childId);
            const currentFees = getFeesForStudent(child.id, currentMonthYear.month);
            const latestFee = currentFees[0];
            const avgScore = testScores.length > 0 
              ? Math.round(testScores.reduce((sum, t) => sum + (t.score / t.total * 100), 0) / testScores.length) 
              : 0;

            return (
              <div key={childId} className="bg-white rounded-2xl shadow-lg p-6 mb-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-blue-900">
                    {child.name}'s Progress Report
                  </h3>
                  <button
                    onClick={() => setShowChildDetails(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <ChevronUp className="h-6 w-6" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                  {/* Performance Card */}
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
                    <div className="flex items-center space-x-3 mb-4">
                      <Award className="h-6 w-6 text-blue-600" />
                      <h4 className="text-lg font-bold text-blue-900">Academic Performance</h4>
                    </div>
                    <div className="text-4xl font-bold text-blue-900 mb-2">{avgScore}%</div>
                    <div className="text-gray-600 text-sm">Average across all tests</div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {testScores.slice(0, 3).map((score) => (
                        <div key={score.id} className="bg-white px-3 py-1 rounded-full text-xs font-medium text-blue-700">
                          {score.testName}: {score.score}/{score.total}
                        </div>
                      ))}
                      {testScores.length === 0 && (
                        <div className="text-gray-500 text-sm italic">No tests taken yet</div>
                      )}
                    </div>
                  </div>

                  {/* Fee Status Card */}
                  <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center space-x-3 mb-4">
                        <CreditCard className="h-6 w-6 text-green-600" />
                        <h4 className="text-lg font-bold text-green-900">Fee Status ({currentMonthYear.month})</h4>
                      </div>
                      <div className={`text-2xl font-bold mb-2 ${latestFee ? 'text-green-600' : 'text-red-600'}`}>
                        {latestFee ? 'PAID' : 'PENDING'}
                      </div>
                      <div className="text-gray-600 text-sm">
                        {latestFee ? (
                          <>
                            <div>Amount: ₹{latestFee.amount}</div>
                            {latestFee.date && (
                              <div className="text-green-600 mt-1 font-medium">
                                Paid on: {latestFee.date}
                              </div>
                            )}
                            {latestFee.receiptNumber && (
                              <div className="text-blue-600 mt-1 font-medium">
                                Receipt No: {latestFee.receiptNumber}
                              </div>
                            )}
                          </>
                        ) : (
                          <div>Fee for {currentMonthYear.month} is pending.</div>
                        )}
                      </div>
                    </div>
                    
                    <div className="mt-4 pt-4 border-t border-green-200">
                      {latestFee ? (
                        <button
                          onClick={() => {
                            const printWindow = window.open('', '_blank');
                            if (printWindow) {
                              printWindow.document.write(`
                                <html><head><title>Fee Receipt</title></head>
                                <body style="font-family: Arial, sans-serif; padding: 40px; max-width: 600px; margin: 0 auto; border: 1px solid #ccc;">
                                  <div style="text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px;">
                                    <h1 style="color: #1e3a8a; margin: 0;">Pandit Maths Classes</h1>
                                    <p style="margin: 5px 0 0;">Behind Sneha Petrol Pump</p>
                                    <p style="margin: 5px 0 0;">Contact: 9244871784, 9755874248</p>
                                  </div>
                                  <h2 style="text-align: center; color: #333;">FEE RECEIPT</h2>
                                  <div style="margin-bottom: 30px;">
                                    <p><strong>Receipt No:</strong> ${latestFee.receiptNumber || 'N/A'}</p>
                                    <p><strong>Date:</strong> ${latestFee.date}</p>
                                    <p><strong>Student Name:</strong> ${child.name}</p>
                                    <p><strong>Class:</strong> ${child.class}</p>
                                  </div>
                                  <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                                    <tr style="background-color: #f3f4f6;">
                                      <th style="padding: 10px; border: 1px solid #ccc; text-align: left;">Description</th>
                                      <th style="padding: 10px; border: 1px solid #ccc; text-align: right;">Amount</th>
                                    </tr>
                                    <tr>
                                      <td style="padding: 10px; border: 1px solid #ccc;">Tuition Fee for ${latestFee.month}</td>
                                      <td style="padding: 10px; border: 1px solid #ccc; text-align: right;">₹${latestFee.amount}</td>
                                    </tr>
                                    <tr>
                                      <th style="padding: 10px; border: 1px solid #ccc; text-align: left;">Total</th>
                                      <th style="padding: 10px; border: 1px solid #ccc; text-align: right;">₹${latestFee.amount}</th>
                                    </tr>
                                  </table>
                                  <div style="margin-top: 50px; display: flex; justify-content: space-between;">
                                    <div><p>___________________</p><p>Parent's Signature</p></div>
                                    <div><p>___________________</p><p>Authorized Signatory</p></div>
                                  </div>
                                  <div style="text-align: center; margin-top: 40px; font-size: 12px; color: #666;">
                                    <p>This is a computer-generated receipt.</p>
                                  </div>
                                </body></html>
                              `);
                              printWindow.document.close();
                              printWindow.print();
                            }
                          }}
                          className="w-full bg-white border border-green-600 text-green-700 py-2 rounded-lg font-semibold hover:bg-green-50 transition-colors"
                        >
                          Download Receipt
                        </button>
                      ) : (
                        <button
                          onClick={() => setPaymentModal({ show: true, studentId: child.id, studentName: child.name, month: currentMonthYear.month, amount: 1000 })}
                          className="w-full bg-green-600 text-white py-2 rounded-lg font-semibold hover:bg-green-700 transition-colors shadow-md flex items-center justify-center"
                        >
                          <CreditCard className="w-4 h-4 mr-2" />
                          Pay Online Now
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Study Materials Card */}
                  <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                    <div className="flex items-center space-x-3 mb-4">
                      <FileText className="h-6 w-6 text-purple-600" />
                      <h4 className="text-lg font-bold text-purple-900">Study Materials</h4>
                    </div>
                    <div className="text-4xl font-bold text-purple-900 mb-2">{child.purchasedMaterials}</div>
                    <div className="text-gray-600 text-sm">Materials purchased</div>
                    <div className="mt-4 text-sm text-gray-600">
                      {child.purchasedMaterials > 0 
                        ? `Great job! ${child.purchasedMaterials} materials have been purchased.`
                        : 'No materials purchased yet.'}
                    </div>
                  </div>
                </div>

                {/* Test Scores Table */}
                <div className="bg-gray-50 rounded-xl p-6">
                  <h4 className="text-lg font-bold text-blue-900 mb-4 flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Recent Test Scores
                  </h4>
                  {testScores.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-gray-300">
                            <th className="text-left py-3 px-4 font-semibold text-gray-700">Test Name</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-700">Score</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-700">Percentage</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-700">Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          {testScores.map((score) => (
                            <tr key={score.id} className="border-b border-gray-200 hover:bg-gray-100">
                              <td className="py-3 px-4">{score.testName}</td>
                              <td className="py-3 px-4 font-semibold">{score.score}/{score.total}</td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  (score.score / score.total) >= 0.8 
                                    ? 'bg-green-100 text-green-800' 
                                    : (score.score / score.total) >= 0.6 
                                    ? 'bg-yellow-100 text-yellow-800' 
                                    : 'bg-red-100 text-red-800'
                                }`}>
                                  {Math.round((score.score / score.total) * 100)}%
                                </span>
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-600">
                                {new Date(score.date).toLocaleDateString()}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Calendar className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>No test scores available yet</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderChildDashboard = () => {
    if (!selectedChild) return null;

    const testScores = getTestScoresForStudent(selectedChild.username);
    const currentMonthYear = getCurrentMonthYear();
    const currentFees = getFeesForStudent(selectedChild.id, currentMonthYear.month);
    const latestFee = currentFees[0];
    const avgScore = testScores.length > 0 
      ? Math.round(testScores.reduce((sum, t) => sum + (t.score / t.total * 100), 0) / testScores.length) 
      : 0;

    return (
      <div className="min-h-screen bg-gray-50 py-8 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <div className="flex items-center space-x-3 mb-2">
                  <GraduationCap className="h-6 w-6 text-blue-600" />
                  <span className="text-blue-600 font-semibold">{selectedChild.class}th Std</span>
                </div>
                <h1 className="text-3xl font-bold text-blue-900">Welcome, {selectedChild.name}</h1>
                <p className="text-gray-600 mt-1">Your academic progress dashboard</p>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>

          {/* Progress Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Performance Card */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
              <div className="flex items-center space-x-3 mb-4">
                <Award className="h-6 w-6 text-blue-600" />
                <h4 className="text-lg font-bold text-blue-900">Performance</h4>
              </div>
              <div className="text-4xl font-bold text-blue-900 mb-2">{avgScore}%</div>
              <div className="text-gray-600 text-sm">Average test score</div>
            </div>

            {/* Fee Status Card */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
              <div className="flex items-center space-x-3 mb-4">
                <CreditCard className="h-6 w-6 text-green-600" />
                <h4 className="text-lg font-bold text-green-900">Fee Status ({currentMonthYear.month})</h4>
              </div>
              <div className={`text-2xl font-bold mb-2 ${latestFee ? 'text-green-600' : 'text-red-600'}`}>
                {latestFee ? '✓ PAID' : '✗ PENDING'}
              </div>
              <div className="text-gray-600 text-sm">
                {latestFee ? `Paid on ${latestFee.date}` : `Please pay your fee for ${currentMonthYear.month}`}
              </div>
            </div>

            {/* Materials Card */}
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
              <div className="flex items-center space-x-3 mb-4">
                <FileText className="h-6 w-6 text-purple-600" />
                <h4 className="text-lg font-bold text-purple-900">Materials</h4>
              </div>
              <div className="text-4xl font-bold text-purple-900 mb-2">{selectedChild.purchasedMaterials}</div>
              <div className="text-gray-600 text-sm">Purchased</div>
            </div>
          </div>

          {/* Test Scores */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-2xl font-bold text-blue-900 mb-6 flex items-center">
              <TrendingUp className="h-6 w-6 mr-2" />
              Your Test Results
            </h3>
            {testScores.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-300">
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Test</th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Score</th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Performance</th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {testScores.map((score) => (
                      <tr key={score.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="py-3 px-4">{score.testName}</td>
                        <td className="py-3 px-4 font-semibold">{score.score}/{score.total}</td>
                        <td className="py-3 px-4">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                            (score.score / score.total) >= 0.8 
                              ? 'bg-green-100 text-green-800' 
                              : (score.score / score.total) >= 0.6 
                              ? 'bg-yellow-100 text-yellow-800' 
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {Math.round((score.score / score.total) * 100)}%
                          </span>
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-600">
                          {new Date(score.date).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-12">
                <TrendingUp className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500 text-lg">No test results yet</p>
                <p className="text-gray-400 text-sm mt-2">Take your first test to see your performance here</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      {!isLoggedIn && renderLogin()}
      {isLoggedIn && loginMode === 'parent' && selectedParent && renderParentDashboard()}
      {isLoggedIn && loginMode === 'child' && selectedChild && renderChildDashboard()}

      {paymentModal && paymentModal.show && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden flex flex-col h-auto max-h-[90vh]">
            <div className="bg-blue-600 text-white p-4 flex justify-between items-center">
              <h3 className="font-bold text-lg flex items-center"><CreditCard className="w-5 h-5 mr-2"/> Pay Online</h3>
              <button onClick={() => setPaymentModal(null)} className="text-white hover:text-gray-200 text-2xl leading-none">&times;</button>
            </div>
            
            <div className="p-6 overflow-y-auto bg-gray-50 flex-1">
              <div className="text-center mb-6 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                <img src="/logo.jpg" alt="Logo" className="w-12 h-12 mx-auto rounded-full mb-2 object-cover border-2 border-blue-100" onError={(e) => { e.currentTarget.style.display='none' }} />
                <h4 className="font-bold text-gray-900 text-lg">Pandit Maths Classes</h4>
                <p className="text-sm text-gray-500">Fee for {paymentModal.studentName} ({paymentModal.month})</p>
                <div className="text-3xl font-bold text-blue-600 mt-2">₹{paymentModal.amount}</div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center relative mb-6">
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-blue-100 text-blue-800 text-xs font-bold px-3 py-1 rounded-full border border-blue-200">SCAN QR TO PAY</div>
                <img 
                  src="/qr.jpg" 
                  alt="Payment QR Code" 
                  className="w-48 h-48 mx-auto mb-4 object-contain rounded-lg border-2 border-gray-100 shadow-sm"
                  onError={(e) => {
                    if (e.currentTarget.src.includes('qrserver')) return;
                    e.currentTarget.src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + encodeURIComponent('upi://pay?pa=panditwrites07@oksbi&pn=Pandit Maths Classes&cu=INR');
                  }}
                />
                <div className="flex items-center justify-center space-x-2 bg-gray-50 p-2 rounded-lg">
                  <span className="text-gray-500 font-medium text-sm">UPI ID:</span>
                  <span className="font-bold text-gray-900 selectable">panditwrites07@oksbi</span>
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-sm text-gray-600 text-center font-medium">After successful payment, please enter the UTR / Transaction ID below to generate your receipt.</p>
                <input
                  type="text"
                  placeholder="Enter 12-digit UTR No."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 uppercase text-center font-mono tracking-widest"
                  value={utrNumber}
                  onChange={(e) => setUtrNumber(e.target.value)}
                />
              </div>
            </div>

            <div className="p-4 bg-white border-t flex space-x-3">
              <button 
                onClick={() => setPaymentModal(null)} 
                className="flex-1 py-3 px-4 rounded-lg font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  if(utrNumber.trim().length < 6) {
                    alert('Please enter a valid UTR or Transaction ID');
                    return;
                  }
                  const newFee = {
                    id: Date.now().toString(),
                    studentId: paymentModal.studentId,
                    month: paymentModal.month,
                    amount: paymentModal.amount,
                    date: new Date().toLocaleDateString(),
                    receiptNumber: 'REC' + Math.floor(Math.random() * 1000000),
                    utr: utrNumber
                  };
                  setFees([...fees, newFee]);
                  setPaymentModal(null);
                  setUtrNumber('');
                  alert('Payment Successful! Receipt Generated.');
                }} 
                className="flex-1 py-3 px-4 rounded-lg font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors shadow-md"
              >
                Confirm Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
