import { useState, useEffect } from 'react';
import { BookOpen, Users, Award, Phone, Mail, MapPin, Target, CheckCircle, ClipboardList, FileText, CreditCard, Activity, MonitorPlay } from 'lucide-react';
import { listenToStudents, getHomePageDataFromFirebase, getTeachersFromFirebase } from './firebase';
import HomeworkPortal from './HomeworkPortal';
import StudyMaterialPortal from './StudyMaterialPortal';
import FeePaymentPortal from './FeePaymentPortal';
import ProgressTrackingPortal from './ProgressTrackingPortal';
import QuizPortal from './QuizPortal';
import TeacherPortal from './TeacherPortal';
import ParentsPortal from './ParentsPortal';

// Register service worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(registration => {
        console.log('SW registered: ', registration);
      })
      .catch(registrationError => {
        console.log('SW registration failed: ', registrationError);
      });
  });
}

interface TeacherInfoDisplay {
  id: string;
  name: string;
  qualification: string;
  subjectsLine: string;
  photoFileName: string;
  photoDataUrl?: string;
}

interface HomePageConfig {
  coachingName: string;
  tagline: string;
  phoneNumbers: string[];
  email: string;
  address: string;
  logoFileName: string;
  logoDataUrl?: string;
  heroTitle: string;
  heroSubtitle: string;
}

export function App() {
  const [showHomework, setShowHomework] = useState(false);
  const [showStudyMaterial, setShowStudyMaterial] = useState(false);
  const [showFees, setShowFees] = useState(false);
  const [showProgress, setShowProgress] = useState(false);
  const [showQuiz, setShowQuiz] = useState(false);
  const [showTeacherPortal, setShowTeacherPortal] = useState(false);
  const [showParentsPortal, setShowParentsPortal] = useState(false);

  const [homePageConfig, setHomePageConfig] = useState<HomePageConfig>(() => {
    const saved = localStorage.getItem('pandit_homepage_config');
    return saved ? JSON.parse(saved) : {
      coachingName: 'Pandit Maths Classes',
      tagline: 'Where Numbers Transform into Dreams',
      phoneNumbers: ['9244871784', '9755874248', '7610784561'],
      email: 'panditmathsclasses@gmail.com',
      address: 'Behind Sneha Petrol Pump',
      logoFileName: 'logo.jpg',
      heroTitle: 'Building Strong Foundations for Future Success',
      heroSubtitle: 'Specialized coaching for Classes 5-10 and entrance exams like Sainik School & Navodaya.',
    };
  });

  const [teacherCards, setTeacherCards] = useState<TeacherInfoDisplay[]>(() => {
    const saved = localStorage.getItem('pandit_teachers');
    return saved ? JSON.parse(saved) : [
      {
        id: 'alok',
        name: 'Alok Mishra',
        qualification: 'All Subjects Faculty',
        subjectsLine: 'All Subjects (Maths, English, Science, SST)',
        photoFileName: 'alok.jpg',
      },
      {
        id: 'abhijeet',
        name: 'Abhijeet Mishra',
        qualification: 'All Subjects Faculty',
        subjectsLine: 'All Subjects (Maths, English, Science, SST)',
        photoFileName: 'abhijeet.jpg',
      },
    ];
  });

  // Listen to Firestore updates in real-time
  useEffect(() => {
    const unsubscribeStudents = listenToStudents((firebaseStudents) => {
      localStorage.setItem('pandit_students', JSON.stringify(firebaseStudents));
    });

    getHomePageDataFromFirebase().then(data => {
      if (data) {
        setHomePageConfig(data as HomePageConfig);
        localStorage.setItem('pandit_homepage_config', JSON.stringify(data));
      }
    });

    getTeachersFromFirebase().then(teachers => {
      if (teachers.length > 0) {
        setTeacherCards(teachers);
        localStorage.setItem('pandit_teachers', JSON.stringify(teachers));
      }
    });

    return () => {
      unsubscribeStudents();
    };
  }, []);

  if (showHomework) return <HomeworkPortal onBack={() => setShowHomework(false)} />;
  if (showStudyMaterial) return <StudyMaterialPortal onBack={() => setShowStudyMaterial(false)} />;
  if (showFees) return <FeePaymentPortal onBack={() => setShowFees(false)} />;
  if (showProgress) return <ProgressTrackingPortal onBack={() => setShowProgress(false)} />;
  if (showQuiz) return <QuizPortal onBack={() => setShowQuiz(false)} />;
  if (showTeacherPortal) return <TeacherPortal onBack={() => setShowTeacherPortal(false)} />;
  if (showParentsPortal) return <ParentsPortal onBack={() => setShowParentsPortal(false)} />;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-sm border-b border-blue-100 shadow-sm">
        <div className="container mx-auto px-4 py-3">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center space-x-4">
              <div className="relative h-16 w-16 overflow-hidden rounded-full border-2 border-blue-600 bg-white shadow-md">
                <img 
                  src={homePageConfig.logoDataUrl || `/${homePageConfig.logoFileName}`} 
                  alt={homePageConfig.coachingName} 
                  className="h-full w-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextElementSibling?.classList.remove('hidden');
                  }}
                />
                <div className="hidden h-full w-full flex items-center justify-center bg-blue-600">
                  <BookOpen className="h-8 w-8 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900 leading-tight">{homePageConfig.coachingName}</h1>
                <p className="text-sm font-medium text-blue-600">{homePageConfig.tagline}</p>
              </div>
            </div>
            
            <div className="flex flex-wrap justify-center gap-4 md:gap-6">
              <a href={`tel:${homePageConfig.phoneNumbers[0]}`} className="flex items-center space-x-2 group">
                <div className="bg-blue-100 p-2 rounded-full group-hover:bg-blue-200 transition-colors">
                  <Phone className="h-4 w-4 text-blue-600" />
                </div>
                <div className="text-sm">
                  <p className="font-semibold text-gray-900">Call Us</p>
                  <p className="text-blue-700 font-medium">{homePageConfig.phoneNumbers.join(' / ')}</p>
                </div>
              </a>
              <div className="hidden sm:flex items-center space-x-2">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Mail className="h-4 w-4 text-blue-600" />
                </div>
                <div className="text-sm">
                  <p className="font-semibold text-gray-900">Email</p>
                  <p className="text-blue-700 font-medium">{homePageConfig.email}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-16 md:py-24 bg-blue-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80')] opacity-10 bg-cover bg-center"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <span className="inline-block px-4 py-1 bg-blue-800 rounded-full text-blue-200 text-sm font-semibold mb-6 border border-blue-700">
              Maths • Science • English
            </span>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              {homePageConfig.heroTitle} <span className="text-yellow-400">Future Success</span>
            </h1>
            <p className="text-xl md:text-2xl mb-10 text-blue-100 max-w-2xl mx-auto">
              {homePageConfig.heroSubtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center flex-wrap">
              <a 
                href="#contact" 
                className="bg-yellow-500 text-blue-900 px-6 py-3 rounded-lg font-bold hover:bg-yellow-400 transition transform hover:-translate-y-1 shadow-lg"
              >
                Enroll Now
              </a>
              <button 
                onClick={() => setShowHomework(true)}
                className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-indigo-500 transition transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-2"
              >
                <ClipboardList size={20} />
                Homework
              </button>
              <button 
                onClick={() => setShowStudyMaterial(true)}
                className="bg-green-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-green-500 transition transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-2"
              >
                <FileText size={20} />
                Materials
              </button>
              <button 
                onClick={() => setShowFees(true)}
                className="bg-purple-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-purple-500 transition transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-2"
              >
                <CreditCard size={20} />
                Fee Portal
              </button>
              <button 
                onClick={() => setShowProgress(true)}
                className="bg-red-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-red-500 transition transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-2"
              >
                <Activity size={20} />
                Progress
              </button>
              <button 
                onClick={() => setShowQuiz(true)}
                className="bg-teal-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-teal-500 transition transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-2"
              >
                <MonitorPlay size={20} />
                Online Test
              </button>
              <button
                onClick={() => setShowTeacherPortal(true)}
                className="bg-orange-500 text-white px-6 py-3 rounded-lg font-bold hover:bg-orange-400 transition transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-2"
              >
                Teacher Portal
              </button>
              <button
                onClick={() => setShowParentsPortal(true)}
                className="bg-pink-500 text-white px-6 py-3 rounded-lg font-bold hover:bg-pink-400 transition transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-2"
              >
                Parents Portal
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Why Choose Pandit Maths Classes?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              We provide comprehensive education in Maths, Science, and English with a focus on conceptual clarity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="group p-6 rounded-2xl bg-blue-50 hover:bg-white hover:shadow-xl transition-all duration-300 border border-blue-100">
              <div className="bg-blue-600 w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <BookOpen className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-3">All Subjects</h3>
              <p className="text-gray-600">
                Comprehensive coaching for Maths, Science, and English for holistic development.
              </p>
            </div>

            <div className="group p-6 rounded-2xl bg-blue-50 hover:bg-white hover:shadow-xl transition-all duration-300 border border-blue-100">
              <div className="bg-blue-600 w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Target className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-3">Exam Focused</h3>
              <p className="text-gray-600">
                Special preparation for Sainik School, Navodaya School, and other competitive exams.
              </p>
            </div>

            <div className="group p-6 rounded-2xl bg-blue-50 hover:bg-white hover:shadow-xl transition-all duration-300 border border-blue-100">
              <div className="bg-blue-600 w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Users className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-3">Personal Attention</h3>
              <p className="text-gray-600">
                Small batch sizes ensure every student gets the attention they need to clarify doubts.
              </p>
            </div>

            <div className="group p-6 rounded-2xl bg-blue-50 hover:bg-white hover:shadow-xl transition-all duration-300 border border-blue-100">
              <div className="bg-blue-600 w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Award className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-3">Quality Teaching</h3>
              <p className="text-gray-600">
                Dedicated teaching with 1 year of experience and proven results with current students.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Fee Structure Section */}
      <section id="fee-structure" className="py-20 bg-blue-50 relative">
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Affordable Fee Structure</h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              Quality education at reasonable prices. Choose the plan that suits your needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 max-w-[90rem] mx-auto">
            {/* Plan 1 */}
            <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden border-t-4 border-blue-500">
              <div className="p-8">
                <h3 className="text-lg font-semibold text-gray-500 mb-2">Class 5–6</h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold text-blue-900">₹750</span>
                  <span className="text-gray-500 ml-2">/month</span>
                </div>
                <p className="text-blue-600 font-medium mb-6 bg-blue-50 inline-block px-3 py-1 rounded-full text-sm">
                  All Subjects
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Mathematics</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Science</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>English</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Basic Foundation</span>
                  </li>
                </ul>
              </div>
              <div className="p-4 bg-gray-50 border-t border-gray-100">
                <a href="#contact" className="block w-full py-2 px-4 bg-white border border-blue-600 text-blue-600 rounded-lg text-center font-semibold hover:bg-blue-50 transition-colors">
                  Join Now
                </a>
              </div>
            </div>

            {/* Plan 2 */}
            <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden border-t-4 border-indigo-500">
              <div className="p-8">
                <h3 className="text-lg font-semibold text-gray-500 mb-2">Class 7–8</h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold text-blue-900">₹1000</span>
                  <span className="text-gray-500 ml-2">/month</span>
                </div>
                <p className="text-indigo-600 font-medium mb-6 bg-indigo-50 inline-block px-3 py-1 rounded-full text-sm">
                  Maths Only
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Advanced Mathematics</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Concept Building</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Problem Solving</span>
                  </li>
                  <li className="flex items-center text-gray-400">
                    <span className="w-5 mr-2 text-center">-</span>
                    <span>Science & English</span>
                  </li>
                </ul>
              </div>
              <div className="p-4 bg-gray-50 border-t border-gray-100">
                <a href="#contact" className="block w-full py-2 px-4 bg-white border border-indigo-600 text-indigo-600 rounded-lg text-center font-semibold hover:bg-indigo-50 transition-colors">
                  Join Now
                </a>
              </div>
            </div>

            {/* Plan 3 */}
            <div className="bg-white rounded-2xl shadow-xl transform scale-105 border-t-4 border-yellow-500 relative">
              <div className="absolute top-0 right-0 bg-yellow-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                POPULAR
              </div>
              <div className="p-8">
                <h3 className="text-lg font-semibold text-gray-500 mb-2">Class 7–8</h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold text-blue-900">₹1500</span>
                  <span className="text-gray-500 ml-2">/month</span>
                </div>
                <p className="text-yellow-600 font-medium mb-6 bg-yellow-50 inline-block px-3 py-1 rounded-full text-sm">
                  Maths + Science + English
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Mathematics</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Science</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>English</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Complete Guidance</span>
                  </li>
                </ul>
              </div>
              <div className="p-4 bg-gray-50 border-t border-gray-100">
                <a href="#contact" className="block w-full py-2 px-4 bg-yellow-500 text-white rounded-lg text-center font-semibold hover:bg-yellow-600 transition-colors shadow-md">
                  Best Value - Join Now
                </a>
              </div>
            </div>

            {/* Plan 3B - New 7-8 All Subjects with SST */}
            <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden border-t-4 border-rose-500">
              <div className="p-8">
                <h3 className="text-lg font-semibold text-gray-500 mb-2">Class 7–8</h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold text-blue-900">₹1800</span>
                  <span className="text-gray-500 ml-2">/month</span>
                </div>
                <p className="text-rose-600 font-medium mb-6 bg-rose-50 inline-block px-3 py-1 rounded-full text-sm">
                  Maths + Science + English + SST
                </p>
                <ul className="space-y-3 mb-8 text-sm">
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>All 4 core subjects</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Strong foundation for Class 9–10</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Regular tests & doubt clearing</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Ideal for school + Olympiad prep</span>
                  </li>
                </ul>
              </div>
              <div className="p-4 bg-gray-50 border-t border-gray-100">
                <a href="#contact" className="block w-full py-2 px-4 bg-rose-500 text-white rounded-lg text-center font-semibold hover:bg-rose-600 transition-colors shadow-md">
                  New Batch - Join Now
                </a>
              </div>
            </div>

            {/* Plan 4 */}
            <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden border-t-4 border-purple-500">
              <div className="p-8">
                <h3 className="text-lg font-semibold text-gray-500 mb-2">Class 9–10</h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold text-blue-900">₹1500</span>
                  <span className="text-gray-500 ml-2">/month</span>
                </div>
                <p className="text-purple-600 font-medium mb-6 bg-purple-50 inline-block px-3 py-1 rounded-full text-sm">
                  Maths Only
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Board Exam Focus</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Advanced Concepts</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Regular Tests</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span>Doubt Sessions</span>
                  </li>
                </ul>
              </div>
              <div className="p-4 bg-gray-50 border-t border-gray-100">
                <a href="#contact" className="block w-full py-2 px-4 bg-white border border-purple-600 text-purple-600 rounded-lg text-center font-semibold hover:bg-purple-50 transition-colors">
                  Join Now
                </a>
              </div>
            </div>

            {/* Plan 5 */}
            <div className="bg-white rounded-2xl shadow-xl transform scale-105 border-t-4 border-red-500 relative">
              <div className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                ALL SUBJECTS
              </div>
              <div className="p-8">
                <h3 className="text-lg font-semibold text-gray-500 mb-2">Class 9–10</h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold text-blue-900">₹2000</span>
                  <span className="text-gray-500 ml-2">/month</span>
                </div>
                <p className="text-red-600 font-medium mb-6 bg-red-50 inline-block px-3 py-1 rounded-full text-sm">
                  Maths+Science+English+SST
                </p>
                <ul className="space-y-3 mb-8 text-sm">
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Mathematics & Science</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>English & SST</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Complete Board Prep</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Regular Tests</span>
                  </li>
                </ul>
              </div>
              <div className="p-4 bg-gray-50 border-t border-gray-100">
                <a href="#contact" className="block w-full py-2 px-4 bg-red-500 text-white rounded-lg text-center font-semibold hover:bg-red-600 transition-colors shadow-md">
                  Join Now
                </a>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Teachers Section */}
      <section className="py-16 bg-blue-900/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-3">Our Teachers</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Experienced, friendly and dedicated teachers helping every student understand concepts clearly.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {teacherCards.map((teacher, index) => (
              <div
                key={teacher.id || index}
                className="bg-white rounded-2xl shadow-lg border border-blue-100 p-6 flex flex-col sm:flex-row items-center gap-5"
              >
                <div className="relative h-28 w-28 rounded-full overflow-hidden border-4 border-blue-600 shadow-md flex-shrink-0">
                  <img
                    src={teacher.photoDataUrl || `/${teacher.photoFileName}`}
                    alt={`${teacher.name} - Pandit Maths Classes`}
                    className="h-full w-full object-cover"
                    onError={e => {
                      e.currentTarget.style.display = 'none';
                      const fallback = e.currentTarget.nextElementSibling as HTMLDivElement | null;
                      if (fallback) fallback.classList.remove('hidden');
                    }}
                  />
                  <div className="hidden h-full w-full bg-blue-600 flex items-center justify-center text-white font-bold text-xl">
                    {teacher.name?.charAt(0) || 'T'}
                  </div>
                </div>
                <div className="text-center sm:text-left">
                  <h3 className="text-xl font-bold text-blue-900">{teacher.name}</h3>
                  <p className="text-blue-700 font-semibold mb-1">{teacher.subjectsLine}</p>
                  <p className="text-gray-600 text-sm mb-2">{teacher.qualification}</p>
                  <p className="text-xs text-gray-500 italic">
                    Teaches: Class 7–10 Maths, Science, English & SST
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="h-1 w-12 bg-blue-600"></div>
                <span className="text-blue-600 font-bold uppercase tracking-wider">About Us</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-6">Dedicated to Academic Excellence</h2>
              <div className="space-y-4 text-gray-700 text-lg">
                <p>
                  <strong>Pandit Maths Classes</strong> was established with a vision to provide quality education 
                  to students from classes 5 to 10. While our core strength lies in Mathematics, we also offer 
                  comprehensive guidance in Science and English.
                </p>
                <p>
                  With one year of dedicated teaching experience, we have developed a unique approach that makes 
                  learning easy and enjoyable. Our focus is on building strong fundamentals that help students 
                  not only in their school curriculum but also in competitive entrance exams.
                </p>
                <div className="flex items-center space-x-4 mt-6">
                  <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-100">
                    <span className="block text-3xl font-bold text-blue-600">5-10</span>
                    <span className="text-sm text-gray-600">Classes</span>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-100">
                    <span className="block text-3xl font-bold text-blue-600">3+</span>
                    <span className="text-sm text-gray-600">Subjects</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-72 h-72 bg-blue-100 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
              <div className="absolute -bottom-8 -right-4 w-72 h-72 bg-purple-100 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
              <div className="bg-white p-8 rounded-2xl shadow-xl border border-blue-100 relative z-10">
                <h3 className="text-2xl font-bold text-blue-900 mb-6">Classes & Subjects</h3>
                <div className="space-y-3">
                  {[
                    { class: 'Class 5', subject: 'Maths, Science, English' },
                    { class: 'Class 6', subject: 'Maths, Science, English' },
                    { class: 'Class 7', subject: 'Maths, Science, English' },
                    { class: 'Class 8', subject: 'Maths, Science, English' },
                    { class: 'Class 9', subject: 'Maths, Science, English, SST' },
                    { class: 'Class 10', subject: 'Maths, Science, English, SST' }
                  ].map((item, index) => (
                    <div key={index} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                      <span className="font-bold text-blue-900 mb-1 sm:mb-0">{item.class}</span>
                      <span className="text-blue-700 text-sm font-medium">
                        {item.subject}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section id="contact" className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
             <div className="order-2 lg:order-1">
               <div className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl border border-white/20">
                 <h2 className="text-3xl font-bold mb-6">Visit Our Center</h2>
                 <div className="space-y-6">
                   <div className="flex items-start space-x-4">
                     <MapPin className="h-6 w-6 text-yellow-400 mt-1 flex-shrink-0" />
                     <div>
                       <h3 className="text-xl font-semibold mb-2">Address</h3>
                       <p className="text-blue-100 text-lg">
                         {homePageConfig.address}
                       </p>
                       <p className="text-blue-200 mt-2 text-sm">
                         Peaceful environment suitable for focused learning.
                       </p>
                     </div>
                   </div>
                   
                   <div className="flex items-start space-x-4">
                     <Phone className="h-6 w-6 text-yellow-400 mt-1 flex-shrink-0" />
                     <div>
                       <h3 className="text-xl font-semibold mb-2">Contact</h3>
                       {homePageConfig.phoneNumbers.map((phone: string, idx: number) => (
                         <p key={idx} className="text-blue-100 text-lg">{phone}</p>
                       ))}
                     </div>
                   </div>

                   <div className="flex items-start space-x-4">
                     <Mail className="h-6 w-6 text-yellow-400 mt-1 flex-shrink-0" />
                     <div>
                       <h3 className="text-xl font-semibold mb-2">Email</h3>
                       <p className="text-blue-100">{homePageConfig.email}</p>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
             
             <div className="order-1 lg:order-2 text-center lg:text-left">
               <h2 className="text-3xl md:text-4xl font-bold mb-6">Convenient Location</h2>
               <p className="text-xl text-blue-200 mb-8">
                 Our coaching center is strategically located behind Sneha Petrol Pump, making it easily 
                 accessible for students. The location provides a quiet atmosphere away from the main road traffic.
               </p>
               <a 
                  href="https://maps.app.goo.gl/F9MU9GFh6V29E4858" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-6 py-3 bg-white text-blue-900 rounded-lg font-bold hover:bg-blue-50 transition-colors"
               >
                 <MapPin className="h-5 w-5 mr-2" />
                 View on Google Maps
               </a>
             </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 border-t border-gray-800">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                          <div className="col-span-1">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="relative h-12 w-12 overflow-hidden rounded-full border-2 border-blue-600 bg-white">
                    <img 
                      src={homePageConfig.logoDataUrl || `/${homePageConfig.logoFileName}`} 
                      alt={homePageConfig.coachingName} 
                      className="h-full w-full object-cover"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                    <div className="hidden h-full w-full flex items-center justify-center bg-blue-600">
                      <BookOpen className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold">{homePageConfig.coachingName}</h3>
                </div>
                <p className="text-gray-400 text-sm">
                  Empowering students with knowledge and confidence in Mathematics, Science, and English.
                </p>
              </div>
            
            <div className="col-span-1">
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#about" className="text-gray-400 hover:text-white transition-colors">About Us</a></li>
                <li><a href="#fee-structure" className="text-gray-400 hover:text-white transition-colors">Fee Structure</a></li>
                <li><a href="#contact" className="text-gray-400 hover:text-white transition-colors">Contact Us</a></li>
              </ul>
            </div>
            
            <div className="col-span-1">
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <ul className="space-y-2">
                <li className="flex items-start space-x-2">
                  <MapPin className="h-4 w-4 text-blue-400 mt-1" />
                  <span className="text-gray-400">{homePageConfig.address}</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Phone className="h-4 w-4 text-blue-400 mt-1" />
                  <span className="text-gray-400">{homePageConfig.phoneNumbers.join(', ')}</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Mail className="h-4 w-4 text-blue-400 mt-1" />
                  <span className="text-gray-400">{homePageConfig.email}</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-gray-800 text-center">
            <p className="text-gray-500">
              © {new Date().getFullYear()} Pandit Maths Classes. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
