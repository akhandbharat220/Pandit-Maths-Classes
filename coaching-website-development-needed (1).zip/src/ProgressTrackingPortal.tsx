import { useState, useEffect } from 'react';
import { Target, LogOut, PlusCircle } from 'lucide-react';

export default function ProgressTrackingPortal({ onBack }: { onBack: () => void }) {
  const [activeTab, setActiveTab] = useState<'home' | 'login'>('login');
  const [session, setSession] = useState<{isLoggedIn: boolean; userType: 'teacher' | 'student' | null; userId?: string; userName?: string}>({ isLoggedIn: false, userType: null });
  const [loginType, setLoginType] = useState<'teacher' | 'student'>('teacher');
  
  const [teacherId, setTeacherId] = useState('');
  const [teacherPassword, setTeacherPassword] = useState('');
  const [studentUsername, setStudentUsername] = useState('');
  const [studentPassword, setStudentPassword] = useState('');

  const [students] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_students');
    return saved ? JSON.parse(saved) : [];
  });

  const [progress, setProgress] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_progress');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('pandit_progress', JSON.stringify(progress));
  }, [progress]);

  const handleTeacherLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (teacherId === 'AM2006' && teacherPassword === '@sk122aa') {
      setSession({ isLoggedIn: true, userType: 'teacher', userId: 'teacher', userName: 'Pandit Sir' });
      setActiveTab('home');
    } else alert('Invalid Teacher Credentials');
  };

  const handleStudentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const student = students.find(s => s.username === studentUsername && s.password === studentPassword);
    if (student) {
      setSession({ isLoggedIn: true, userType: 'student', userId: student.id, userName: student.name });
      setActiveTab('home');
    } else alert('Invalid Student Credentials');
  };

  const [testScore, setTestScore] = useState({ studentId: '', testName: '', score: '', maxScore: '' });

  const addScore = (e: React.FormEvent) => {
    e.preventDefault();
    const newProgress = { id: Date.now().toString(), date: new Date().toISOString().split('T')[0], ...testScore };
    setProgress([...progress, newProgress]);
    alert('Progress added!');
    setTestScore({ studentId: '', testName: '', score: '', maxScore: '' });
  };

  const renderLogin = () => (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-lg p-8">
        <button onClick={onBack} className="mb-6 text-blue-600 hover:underline">← Back to Home</button>
        <h2 className="text-2xl font-bold mb-6 text-center">Progress Portal Login</h2>
        <div className="flex mb-6 bg-gray-100 rounded p-1">
          <button onClick={() => setLoginType('teacher')} className={`flex-1 py-2 rounded text-sm font-medium ${loginType === 'teacher' ? 'bg-white shadow' : ''}`}>Teacher</button>
          <button onClick={() => setLoginType('student')} className={`flex-1 py-2 rounded text-sm font-medium ${loginType === 'student' ? 'bg-white shadow' : ''}`}>Student</button>
        </div>
        {loginType === 'teacher' ? (
          <form onSubmit={handleTeacherLogin} className="space-y-4">
            <input type="text" placeholder="Teacher ID" value={teacherId} onChange={e => setTeacherId(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <input type="password" placeholder="Password" value={teacherPassword} onChange={e => setTeacherPassword(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg">Login</button>
          </form>
        ) : (
          <form onSubmit={handleStudentLogin} className="space-y-4">
            <input type="text" placeholder="Username" value={studentUsername} onChange={e => setStudentUsername(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <input type="password" placeholder="Password" value={studentPassword} onChange={e => setStudentPassword(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg">Login</button>
          </form>
        )}
      </div>
    </div>
  );

  const renderTeacherPortal = () => (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Track Student Progress</h2>
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold text-lg mb-4 flex items-center"><PlusCircle className="mr-2" /> Add Test Score</h3>
          <form onSubmit={addScore} className="space-y-4">
            <select value={testScore.studentId} onChange={e => setTestScore({...testScore, studentId: e.target.value})} className="w-full px-4 py-2 border rounded" required>
              <option value="">Select Student</option>
              {students.map(s => <option key={s.id} value={s.id}>{s.name} (Class {s.class})</option>)}
            </select>
            <input type="text" placeholder="Test Name (e.g. Weekly Test 1)" value={testScore.testName} onChange={e => setTestScore({...testScore, testName: e.target.value})} className="w-full px-4 py-2 border rounded" required />
            <div className="flex space-x-4">
              <input type="number" placeholder="Marks Obtained" value={testScore.score} onChange={e => setTestScore({...testScore, score: e.target.value})} className="w-1/2 px-4 py-2 border rounded" required />
              <input type="number" placeholder="Max Marks" value={testScore.maxScore} onChange={e => setTestScore({...testScore, maxScore: e.target.value})} className="w-1/2 px-4 py-2 border rounded" required />
            </div>
            <button className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Add Score</button>
          </form>
        </div>
        <div className="bg-white rounded-xl shadow p-6 max-h-96 overflow-y-auto">
          <h3 className="font-semibold text-lg mb-4">Recent Tests</h3>
          {progress.length === 0 ? <p className="text-gray-500">No test records found.</p> : (
            <ul className="space-y-3">
              {progress.slice().reverse().map(p => {
                const s = students.find(stu => stu.id === p.studentId);
                return (
                  <li key={p.id} className="flex flex-col border-b pb-2">
                    <span className="font-semibold">{s?.name || 'Unknown Student'} - {p.testName}</span>
                    <span className="text-sm text-gray-500">{p.date} • Score: {p.score}/{p.maxScore}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </div>
  );

  const renderStudentPortal = () => {
    const studentProgress = progress.filter(p => p.studentId === session.userId);

    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-6">My Academic Progress</h2>
        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold text-lg mb-4">Test Scores</h3>
          {studentProgress.length === 0 ? <p className="text-gray-500">No test records found.</p> : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {studentProgress.map(p => (
                <div key={p.id} className="border rounded-lg p-4 bg-blue-50">
                  <h4 className="font-bold text-gray-800">{p.testName}</h4>
                  <p className="text-sm text-gray-500 mb-2">{p.date}</p>
                  <div className="flex justify-between items-center bg-white p-2 rounded">
                    <span>Score:</span>
                    <span className="font-bold text-blue-600 text-lg">{p.score} / {p.maxScore}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  if (activeTab === 'login') return renderLogin();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <button onClick={onBack} className="mr-4 text-blue-600 hover:underline">← Back</button>
          <Target className="w-6 h-6 text-blue-600 mr-2" />
          <h1 className="text-xl font-bold">Progress Portal</h1>
        </div>
        <button onClick={() => setActiveTab('login')} className="flex items-center text-red-600"><LogOut className="w-4 h-4 mr-1"/> Logout</button>
      </header>
      <div className="container mx-auto">
        {session.userType === 'teacher' ? renderTeacherPortal() : renderStudentPortal()}
      </div>
    </div>
  );
}