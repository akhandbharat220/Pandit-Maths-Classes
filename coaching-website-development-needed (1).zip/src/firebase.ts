import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, getDoc, getDocs, updateDoc, onSnapshot } from 'firebase/firestore';

// Your Firebase Config (Hardcoded)
const firebaseConfig = {
  apiKey: "AIzaSyD-nnshrjah3PMUr-F4OxZpQlHIGdR-LzQ",
  authDomain: "pandit-maths-classes.firebaseapp.com",
  projectId: "pandit-maths-classes",
  storageBucket: "pandit-maths-classes.firebasestorage.app",
  messagingSenderId: "19978240546",
  appId: "1:19978240546:web:36b0571e69a506897d007b",
  measurementId: "G-WNDP4QJ4Q6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db, app };

// Student functions
export const saveStudentToFirebase = async (student: any) => {
  try {
    await setDoc(doc(db, 'students', student.username), student);
    console.log('Student saved to Firebase:', student.username);
    return true;
  } catch (error) {
    console.error('Error saving student:', error);
    return false;
  }
};

export const getStudentFromFirebase = async (username: string) => {
  try {
    const docRef = doc(db, 'students', username);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data();
    }
    return null;
  } catch (error) {
    console.error('Error getting student:', error);
    return null;
  }
};

export const getAllStudentsFromFirebase = async () => {
  try {
    const querySnapshot = await getDocs(collection(db, 'students'));
    const students: any[] = [];
    querySnapshot.forEach((doc) => {
      students.push(doc.data());
    });
    return students;
  } catch (error) {
    console.error('Error getting all students:', error);
    return [];
  }
};

export const updateStudentInFirebase = async (username: string, data: any) => {
  try {
    const docRef = doc(db, 'students', username);
    await updateDoc(docRef, data);
    return true;
  } catch (error) {
    console.error('Error updating student:', error);
    return false;
  }
};

// Parent functions
export const saveParentToFirebase = async (parent: any) => {
  try {
    await setDoc(doc(db, 'parents', parent.parentId), parent);
    console.log('Parent saved to Firebase:', parent.parentId);
    return true;
  } catch (error) {
    console.error('Error saving parent:', error);
    return false;
  }
};

export const getParentFromFirebase = async (parentId: string) => {
  try {
    const docRef = doc(db, 'parents', parentId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data();
    }
    return null;
  } catch (error) {
    console.error('Error getting parent:', error);
    return null;
  }
};

export const getAllParentsFromFirebase = async () => {
  try {
    const querySnapshot = await getDocs(collection(db, 'parents'));
    const parents: any[] = [];
    querySnapshot.forEach((doc) => {
      parents.push(doc.data());
    });
    return parents;
  } catch (error) {
    console.error('Error getting all parents:', error);
    return [];
  }
};

// Teacher functions
export const saveTeacherToFirebase = async (teacher: any) => {
  try {
    await setDoc(doc(db, 'teachers', teacher.id), teacher);
    console.log('Teacher saved to Firebase:', teacher.id);
    return true;
  } catch (error) {
    console.error('Error saving teacher:', error);
    return false;
  }
};

export const getTeachersFromFirebase = async () => {
  try {
    const querySnapshot = await getDocs(collection(db, 'teachers'));
    const teachers: any[] = [];
    querySnapshot.forEach((doc) => {
      teachers.push(doc.data());
    });
    return teachers;
  } catch (error) {
    console.error('Error getting teachers:', error);
    return [];
  }
};

// Home page data functions
export const saveHomePageDataToFirebase = async (data: any) => {
  try {
    await setDoc(doc(db, 'settings', 'homepage'), data);
    console.log('Home page data saved to Firebase');
    return true;
  } catch (error) {
    console.error('Error saving home page data:', error);
    return false;
  }
};

export const getHomePageDataFromFirebase = async () => {
  try {
    const docRef = doc(db, 'settings', 'homepage');
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data();
    }
    return null;
  } catch (error) {
    console.error('Error getting home page data:', error);
    return null;
  }
};

// Listen to real-time updates
export const listenToStudents = (callback: (students: any[]) => void) => {
  return onSnapshot(collection(db, 'students'), (snapshot) => {
    const students: any[] = [];
    snapshot.forEach((doc) => {
      students.push(doc.data());
    });
    callback(students);
  });
};

export const listenToParents = (callback: (parents: any[]) => void) => {
  return onSnapshot(collection(db, 'parents'), (snapshot) => {
    const parents: any[] = [];
    snapshot.forEach((doc) => {
      parents.push(doc.data());
    });
    callback(parents);
  });
};

export default app;