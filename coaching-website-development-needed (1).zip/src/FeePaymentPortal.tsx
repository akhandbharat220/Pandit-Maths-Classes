import { useState, useEffect } from 'react';
import { CreditCard, LogOut, CheckCircle, Clock } from 'lucide-react';
import { getStudentFromFirebase, getAllStudentsFromFirebase } from './firebase';

export default function FeePaymentPortal({ onBack }: { onBack: () => void }) {
  const [activeTab, setActiveTab] = useState<'home' | 'login'>('login');
  const [session, setSession] = useState<{isLoggedIn: boolean; userType: 'teacher' | 'student' | null; userId?: string; userName?: string}>({ isLoggedIn: false, userType: null });
  const [loginType, setLoginType] = useState<'teacher' | 'student'>('teacher');
  
  const [teacherId, setTeacherId] = useState('');
  const [teacherPassword, setTeacherPassword] = useState('');
  const [studentUsername, setStudentUsername] = useState('');
  const [studentPassword, setStudentPassword] = useState('');
  const [paymentModal, setPaymentModal] = useState<{show: boolean, studentId: string, month: string, amount: number} | null>(null);
  const [utrNumber, setUtrNumber] = useState('');

  const [students, setStudents] = useState<any[]>([]);
  
  // Load students from Firebase
  useEffect(() => {
    getAllStudentsFromFirebase().then(firebaseStudents => {
      setStudents(firebaseStudents);
    });
    
    // Also listen for localStorage updates (when Teacher adds new student)
    const handleStorageChange = () => {
      getAllStudentsFromFirebase().then(firebaseStudents => {
        setStudents(firebaseStudents);
      });
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const [fees, setFees] = useState<any[]>(() => {
    const saved = localStorage.getItem('pandit_fees');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('pandit_fees', JSON.stringify(fees));
  }, [fees]);

  const handleTeacherLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (teacherId === 'AM2006' && teacherPassword === '@sk122aa') {
      setSession({ isLoggedIn: true, userType: 'teacher', userId: 'teacher', userName: 'Pandit Sir' });
      setActiveTab('home');
    } else alert('Invalid Teacher Credentials');
  };

  const handleStudentLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    // First check localStorage for immediate access
    const localStudents = JSON.parse(localStorage.getItem('pandit_students') || '[]');
    const localStudent = localStudents.find((s: any) => s.username === studentUsername && s.password === studentPassword);
    
    if (localStudent) {
      setSession({ isLoggedIn: true, userType: 'student', userId: localStudent.id, userName: localStudent.name });
      setActiveTab('home');
      return;
    }
    
    // If not in localStorage, check Firebase
    const firebaseStudent = await getStudentFromFirebase(studentUsername);
    if (firebaseStudent && firebaseStudent.password === studentPassword) {
      setSession({ isLoggedIn: true, userType: 'student', userId: firebaseStudent.id, userName: firebaseStudent.name });
      setActiveTab('home');
    } else {
      alert('Invalid Student Credentials');
    }
  };

  const markFeePaid = (studentId: string, month: string, amount: number) => {
    const receiptNumber = 'REC' + Math.floor(Math.random() * 1000000);
    const newFee = { 
      id: Date.now().toString(), 
      studentId, 
      month, 
      amount, 
      date: new Date().toLocaleDateString(),
      receiptNumber 
    };
    setFees([...fees, newFee]);
    alert(`Fee marked as paid! Receipt Number: ${receiptNumber}`);
  };

  const generateReceipt = (student: any, fee: any) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html><head><title>Fee Receipt</title></head>
        <body style="font-family: Arial, sans-serif; padding: 40px; max-width: 600px; margin: 0 auto; border: 1px solid #ccc;">
          <div style="text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px;">
            <h1 style="color: #1e3a8a; margin: 0;">Pandit Maths Classes</h1>
            <p style="margin: 5px 0 0;">Behind Sneha Petrol Pump</p>
            <p style="margin: 5px 0 0;">Contact: 9244871784, 9755874248</p>
          </div>
          <h2 style="text-align: center; color: #333;">FEE RECEIPT</h2>
          <div style="margin-bottom: 30px;">
            <p><strong>Receipt No:</strong> ${fee.receiptNumber || 'N/A'}</p>
            <p><strong>Date:</strong> ${fee.date}</p>
            <p><strong>Student Name:</strong> ${student.name}</p>
            <p><strong>Class:</strong> ${student.class}</p>
          </div>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
            <tr style="background-color: #f3f4f6;">
              <th style="padding: 10px; border: 1px solid #ccc; text-align: left;">Description</th>
              <th style="padding: 10px; border: 1px solid #ccc; text-align: right;">Amount</th>
            </tr>
            <tr>
              <td style="padding: 10px; border: 1px solid #ccc;">Tuition Fee for ${fee.month}</td>
              <td style="padding: 10px; border: 1px solid #ccc; text-align: right;">₹${fee.amount}</td>
            </tr>
            <tr>
              <th style="padding: 10px; border: 1px solid #ccc; text-align: left;">Total</th>
              <th style="padding: 10px; border: 1px solid #ccc; text-align: right;">₹${fee.amount}</th>
            </tr>
          </table>
          <div style="margin-top: 50px; display: flex; justify-content: space-between;">
            <div><p>___________________</p><p>Parent's Signature</p></div>
            <div><p>___________________</p><p>Authorized Signatory</p></div>
          </div>
          <div style="text-align: center; margin-top: 40px; font-size: 12px; color: #666;">
            <p>This is a computer-generated receipt.</p>
          </div>
        </body></html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const currentMonth = months[new Date().getMonth()];

  const renderLogin = () => (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-lg p-8">
        <button onClick={onBack} className="mb-6 text-blue-600 hover:underline">← Back to Home</button>
        <h2 className="text-2xl font-bold mb-6 text-center">Fee Portal Login</h2>
        <div className="flex mb-6 bg-gray-100 rounded p-1">
          <button onClick={() => setLoginType('teacher')} className={`flex-1 py-2 rounded text-sm font-medium ${loginType === 'teacher' ? 'bg-white shadow' : ''}`}>Teacher</button>
          <button onClick={() => setLoginType('student')} className={`flex-1 py-2 rounded text-sm font-medium ${loginType === 'student' ? 'bg-white shadow' : ''}`}>Student</button>
        </div>
        {loginType === 'teacher' ? (
          <form onSubmit={handleTeacherLogin} className="space-y-4">
            <input type="text" placeholder="Teacher ID" value={teacherId} onChange={e => setTeacherId(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <input type="password" placeholder="Password" value={teacherPassword} onChange={e => setTeacherPassword(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg">Login</button>
          </form>
        ) : (
          <form onSubmit={handleStudentLogin} className="space-y-4">
            <input type="text" placeholder="Username" value={studentUsername} onChange={e => setStudentUsername(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <input type="password" placeholder="Password" value={studentPassword} onChange={e => setStudentPassword(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg">Login</button>
          </form>
        )}
      </div>
    </div>
  );

  const renderTeacherPortal = () => (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Manage Student Fees</h2>
      <div className="bg-white rounded-xl shadow p-6">
        {students.length === 0 ? <p>No students registered.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead><tr className="border-b"><th className="py-2">Student</th><th className="py-2">Class</th><th className="py-2">Current Month ({currentMonth})</th><th className="py-2">Action</th></tr></thead>
              <tbody>
                {students.map(student => {
                  const isPaidThisMonth = fees.some(f => f.studentId === student.id && f.month === currentMonth);
                  return (
                    <tr key={student.id} className="border-b">
                      <td className="py-3">{student.name}</td>
                      <td>{student.class}</td>
                      <td>
                        {isPaidThisMonth ? <span className="text-green-600 flex items-center"><CheckCircle className="w-4 h-4 mr-1"/> Paid</span> : <span className="text-red-600 flex items-center"><Clock className="w-4 h-4 mr-1"/> Pending</span>}
                      </td>
                      <td className="flex gap-2">
                        {!isPaidThisMonth ? (
                          <button onClick={() => markFeePaid(student.id, currentMonth, 1000)} className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700">Mark Paid</button>
                        ) : (
                          <button onClick={() => {
                            const fee = fees.find(f => f.studentId === student.id && f.month === currentMonth);
                            if(fee) generateReceipt(student, fee);
                          }} className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700">Print Receipt</button>
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );

  const renderStudentPortal = () => {
    const studentFees = fees.filter(f => f.studentId === session.userId);
    const isPaidThisMonth = studentFees.some(f => f.month === currentMonth);

    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-6">My Fee Status</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow p-6 border-t-4 border-blue-500">
            <h3 className="font-semibold text-lg mb-2">Current Month: {currentMonth}</h3>
            {isPaidThisMonth ? (
              <div className="flex items-center text-green-600 text-xl font-bold"><CheckCircle className="mr-2"/> Fee Paid</div>
            ) : (
              <div>
                <div className="flex items-center text-red-600 text-xl font-bold mb-4"><Clock className="mr-2"/> Fee Pending</div>
                <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded border mb-4">Please pay your fee online via UPI to generate an instant receipt.</p>
                <button
                  onClick={() => setPaymentModal({ show: true, studentId: session.userId!, month: currentMonth, amount: 1000 })}
                  className="w-full bg-green-600 text-white py-2 rounded-lg font-semibold hover:bg-green-700 transition-colors shadow-md flex items-center justify-center"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Pay Online Now
                </button>
              </div>
            )}
          </div>
          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="font-semibold text-lg mb-4">Payment History</h3>
            {studentFees.length === 0 ? <p className="text-gray-500">No payment records found.</p> : (
              <ul className="space-y-3">
                {studentFees.map(f => (
                  <li key={f.id} className="flex justify-between border-b pb-2">
                    <span>{f.month} Fee</span>
                    <span className="text-green-600 font-medium">₹{f.amount} (Paid on {f.date})</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    );
  };

  if (activeTab === 'login') return renderLogin();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <button onClick={onBack} className="mr-4 text-blue-600 hover:underline">← Back</button>
          <CreditCard className="w-6 h-6 text-blue-600 mr-2" />
          <h1 className="text-xl font-bold">Fee Payment Portal</h1>
        </div>
        <button onClick={() => setActiveTab('login')} className="flex items-center text-red-600"><LogOut className="w-4 h-4 mr-1"/> Logout</button>
      </header>
      <div className="container mx-auto">
        {session.userType === 'teacher' ? renderTeacherPortal() : renderStudentPortal()}
      </div>

      {paymentModal && paymentModal.show && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden flex flex-col h-auto max-h-[90vh]">
            <div className="bg-blue-600 text-white p-4 flex justify-between items-center">
              <h3 className="font-bold text-lg flex items-center"><CreditCard className="w-5 h-5 mr-2"/> Pay Online</h3>
              <button onClick={() => setPaymentModal(null)} className="text-white hover:text-gray-200 text-2xl leading-none">&times;</button>
            </div>
            
            <div className="p-6 overflow-y-auto bg-gray-50 flex-1">
              <div className="text-center mb-6 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                <img src="/logo.jpg" alt="Logo" className="w-12 h-12 mx-auto rounded-full mb-2 object-cover border-2 border-blue-100" onError={(e) => { e.currentTarget.style.display='none' }} />
                <h4 className="font-bold text-gray-900 text-lg">Pandit Maths Classes</h4>
                <p className="text-sm text-gray-500">Fee for {paymentModal.month}</p>
                <div className="text-3xl font-bold text-blue-600 mt-2">₹{paymentModal.amount}</div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center relative mb-6">
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-blue-100 text-blue-800 text-xs font-bold px-3 py-1 rounded-full border border-blue-200">SCAN QR TO PAY</div>
                <img 
                  src="/qr.jpg" 
                  alt="Payment QR Code" 
                  className="w-48 h-48 mx-auto mb-4 object-contain rounded-lg border-2 border-gray-100 shadow-sm"
                  onError={(e) => {
                    if (e.currentTarget.src.includes('qrserver')) return;
                    e.currentTarget.src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + encodeURIComponent('upi://pay?pa=panditwrites07@oksbi&pn=Pandit Maths Classes&cu=INR');
                  }}
                />
                <div className="flex items-center justify-center space-x-2 bg-gray-50 p-2 rounded-lg">
                  <span className="text-gray-500 font-medium text-sm">UPI ID:</span>
                  <span className="font-bold text-gray-900 selectable">panditwrites07@oksbi</span>
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-sm text-gray-600 text-center font-medium">After successful payment, please enter the UTR / Transaction ID below.</p>
                <input
                  type="text"
                  placeholder="Enter 12-digit UTR No."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 uppercase text-center font-mono tracking-widest"
                  value={utrNumber}
                  onChange={(e) => setUtrNumber(e.target.value)}
                />
              </div>
            </div>

            <div className="p-4 bg-white border-t flex space-x-3">
              <button 
                onClick={() => setPaymentModal(null)} 
                className="flex-1 py-3 px-4 rounded-lg font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  if(utrNumber.trim().length < 6) {
                    alert('Please enter a valid UTR or Transaction ID');
                    return;
                  }
                  markFeePaid(paymentModal.studentId, paymentModal.month, paymentModal.amount);
                  setPaymentModal(null);
                  setUtrNumber('');
                }} 
                className="flex-1 py-3 px-4 rounded-lg font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors shadow-md"
              >
                Confirm Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
